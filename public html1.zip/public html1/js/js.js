function changeplan(plan) {
    var vplan = plan;
   switch (plan)
	{
	case '1':
			document.getElementById('p_min').innerHTML = 30;
			document.getElementById('p_max').innerHTML = 499;
			document.getElementById('p_dora').innerHTML= 'daily for';
			document.getElementById('p_days').innerHTML=9;
			document.getElementById('p_perc').innerHTML=13;
			break;
	case '2':
				document.getElementById('p_min').innerHTML = 500;
			document.getElementById('p_max').innerHTML = 1999;
			document.getElementById('p_dora').innerHTML= 'after';
			document.getElementById('p_days').innerHTML=7;
			document.getElementById('p_perc').innerHTML=160;
			break;
	case '3':
				document.getElementById('p_min').innerHTML = 2000;
			document.getElementById('p_max').innerHTML = 4999;
			document.getElementById('p_dora').innerHTML= 'after';
			document.getElementById('p_days').innerHTML=5;
			document.getElementById('p_perc').innerHTML=250;
			break;
	case '4':
			document.getElementById('p_min').innerHTML = 5000;
			document.getElementById('p_max').innerHTML = 100000;
			document.getElementById('p_dora').innerHTML= 'after';
			document.getElementById('p_days').innerHTML=3;
			document.getElementById('p_perc').innerHTML=450;
			break;
	}
	
	$(".calculate-select").val(vplan);
	$(".calculate-amount").val(0);
	$(".total").val(0);
} 