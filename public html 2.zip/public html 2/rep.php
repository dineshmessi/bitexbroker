
 <!DOCTYPE html>
<html lang="en">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="3;url=representative.php">

  <link href="images/favicon.png" rel="icon" />
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css" />
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<!-- fonts link in the tab--->
<link href="https://fonts.googleapis.com/css?family=Bai+Jamjuree&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Bai+Jamjuree&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet"><link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet">
<style type="text/css">
  .idname {
font-family:poppins,sans-serif;
font-size:18px;
  
top:35%;
left:35%;
color:green;}

.bhm
{
margin:auto;
text-decoration:none;
color:gray;
font-family:poppins,sans-serif;
font-size:16px;
margin-top:100px !important;}

.idname{
margin:100px 0px;}
.text{
  font-family:poppins,sans-serif;
  font-size:16px;
  color: #0ddb9a;
}
</style>
<body>

  

<?php

$ct = time();
$id = rand(1,9)*$ct;

$name = $_POST['name'];
$email = $_POST['email'];
$country = $_POST['country'];
$number = $_POST['number'];
$skype = $_POST['skype'];

$userArray = $id.'*USep*'.$name.'*USep*'.$email.'*USep*'.$country.'*USep*'.$number.'*USep*'.$skype."*end*\n";

$aproveurl = 'https://www.bitexbroker.com/approverep.php?id='.$id;

$to = "refs@bitexbroker.com";
$subject = "New representative request received.";
$txt = "You have received a new representative request. Click the below link to accept now. Ignore to delete!<br><BR>".$aproveurl;
// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
// More headers
$headers .= 'From: <admin@bitexbroker.com>' . "\r\n";

mail($to,$subject,$txt,$headers);

$file = 'trepdb.txt';
$data = $userArray;
file_put_contents($file, $data, FILE_APPEND);

?>


<div class="idname text-center ">

<img src="images/handsh.gif"><br>
 <?php
  echo "Successfully added  " .$name. " as our  representative\n";

?>
</div>
  <div class="text-center">
      <img src="images/rep.png" style="width:100px">
      <br>
      <p class="text"> Redirecting to Representative page ...</p>

</div>

</body></html>
