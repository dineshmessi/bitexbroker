<?php

$repId = $_GET['id'];

$checkFile = file_get_contents("repdb.txt");
$finalUsers = explode('*end*', $checkFile);

foreach($finalUsers as $u) {
    if (strpos($u, $repId) !== false) {
        echo 'User already exist';
        return;
    }
}

$fileData = file_get_contents("trepdb.txt");
$allUsers = explode('*end*', $fileData);

foreach($allUsers as $user) {
    if (strpos($user, $repId) !== false) {
        $foundUser = $user;
        $foundUser = $foundUser."*end*\n";
        break;
    }
}
if(isset($foundUser)) {
        
    $file = 'repdb.txt';
    $data = $foundUser;
    
    file_put_contents($file, $data, FILE_APPEND);
    echo "Approved!";
    
} else {
    echo 'Representative row not found!';
}

?>