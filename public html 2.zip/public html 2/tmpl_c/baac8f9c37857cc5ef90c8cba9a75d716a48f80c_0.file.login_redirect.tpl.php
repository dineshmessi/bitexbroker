<?php /* Smarty version 3.1.27, created on 2019-11-27 20:26:31
         compiled from "/home/h27610/public_html/tmpl/login_redirect.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:10271486125ddedbf7ad0bd5_33887171%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'baac8f9c37857cc5ef90c8cba9a75d716a48f80c' => 
    array (
      0 => '/home/h27610/public_html/tmpl/login_redirect.tpl',
      1 => 1574753639,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10271486125ddedbf7ad0bd5_33887171',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5ddedbf7b2f799_31801360',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5ddedbf7b2f799_31801360')) {
function content_5ddedbf7b2f799_31801360 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/h27610/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '10271486125ddedbf7ad0bd5_33887171';
?>
<html>
<head>
<META HTTP-EQUIV=Refresh CONTENT="6; URL=<?php echo smarty_modifier_myescape(encurl("?a=account"));?>
">
</head>
<body>
	
	<style>
	    body {
background:#fff;
text-align:center;
}
.loader {
margin:auto;
}
	    
	</style>
	
<div class="loader text-center">
	<center style="font-family:poppins,sans-serif;">
<img src="template/910.gif" style="width:100px;margin-top:10%"/>

</center>
</div>
	
<body>
</html><?php }
}
?>