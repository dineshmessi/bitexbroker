<?php /* Smarty version 3.1.27, created on 2019-11-27 20:37:18
         compiled from "/home/h27610/public_html/tmpl/signup.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:21121959535ddede7e731444_78741942%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f0ced5dbd6d76f38e8a6fc0e10625b87411655d2' => 
    array (
      0 => '/home/h27610/public_html/tmpl/signup.tpl',
      1 => 1574881440,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21121959535ddede7e731444_78741942',
  'variables' => 
  array (
    'deny_registration' => 0,
    'settings' => 0,
    'referer' => 0,
    'errors' => 0,
    'frm' => 0,
    'countries' => 0,
    'pay_accounts' => 0,
    'ps' => 0,
    'mpay_accounts' => 0,
    'p' => 0,
    'userinfo' => 0,
    'ti' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5ddede7e877f43_91636135',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5ddede7e877f43_91636135')) {
function content_5ddede7e877f43_91636135 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/h27610/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '21121959535ddede7e731444_78741942';
echo $_smarty_tpl->getSubTemplate ("hustydesigns_framework/header_inners.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<?php if ($_smarty_tpl->tpl_vars['deny_registration']->value) {?>
 We are closed for new registrations now.
<?php } elseif ($_smarty_tpl->tpl_vars['settings']->value['use_referal_program'] && $_smarty_tpl->tpl_vars['settings']->value['force_upline'] && !$_smarty_tpl->tpl_vars['referer']->value && !$_smarty_tpl->tpl_vars['settings']->value['get_rand_ref']) {?>
 You  do not have a upline. Our system require a upline for each user.
<?php } else { ?>
 

 <?php echo '<script'; ?>
 language=javascript>
 function checkform() {
  if (document.regform.fullname.value == '') {
    alert("Please enter your full name!");
    document.regform.fullname.focus();
    return false;
  }
 
 <?php if ($_smarty_tpl->tpl_vars['settings']->value['use_user_location'] == 1) {?>
 
  if (document.regform.address.value == '') {
    alert("Please enter your address!");
    document.regform.address.focus();
    return false;
  }
  if (document.regform.city.value == '') {
    alert("Please enter your city!");
    document.regform.city.focus();
    return false;
  }
  if (document.regform.state.value == '') {
    alert("Please enter your state!");
    document.regform.state.focus();
    return false;
  }
  if (document.regform.zip.value == '') {
    alert("Please enter your ZIP!");
    document.regform.zip.focus();
    return false;
  }
  if (document.regform.country.options[document.regform.country.selectedIndex].text == '--SELECT--') {
    alert("Please choose your country!");
    document.regform.country.focus();
    return false;
  }
 
 <?php }?>
 
  if (document.regform.username.value == '') {
    alert("Please enter your username!");
    document.regform.username.focus();
    return false;
  }
  if (!document.regform.username.value.match(/^[A-Za-z0-9_\-]+$/)) {
    alert("For username you should use English letters and digits only!");
    document.regform.username.focus();
    return false;
  }
  if (document.regform.password.value == '') {
    alert("Please enter your password!");
    document.regform.password.focus();
    return false;
  }
  if (document.regform.password.value != document.regform.password2.value) {
    alert("Please check your password!");
    document.regform.password2.focus();
    return false;
  }
 
 <?php if ($_smarty_tpl->tpl_vars['settings']->value['use_transaction_code']) {?>
 
  if (document.regform.transaction_code.value == '') {
    alert("Please enter your transaction code!");
    document.regform.transaction_code.focus();
    return false;
  }
  if (document.regform.transaction_code.value != document.regform.transaction_code2.value) {
    alert("Please check your transaction code!");
    document.regform.transaction_code2.focus();
    return false;
  }
 
 <?php }?>
 
  if (document.regform.email.value == '') {
    alert("Please enter your e-mail address!");
    document.regform.email.focus();
    return false;
  }
  if (document.regform.email.value != document.regform.email1.value) {
    alert("Please retupe your e-mail!");
    document.regform.email.focus();
    return false;
  }
  if (document.regform.agree.checked == false) {
    alert("You have to agree with the Terms and Conditions!");
    return false;
  }
  return true;
 }

 function IsNumeric(sText) {
  var ValidChars = "0123456789";
  var IsNumber=true;
  var Char;
  if (sText == '') return false;
  for (i = 0; i < sText.length && IsNumber == true; i++) { 
    Char = sText.charAt(i); 
    if (ValidChars.indexOf(Char) == -1) {
      IsNumber = false;
    }
  }
  return IsNumber;
 }
 <?php echo '</script'; ?>
>
 
 
 <?php if ($_smarty_tpl->tpl_vars['errors']->value) {?>
  <ul class="hderrorbox">
  <?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['e'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['e']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['e']['name'] = 'e';
$_smarty_tpl->tpl_vars['smarty']->value['section']['e']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['errors']->value) ? count($_loop) : max(0, (int) $_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['e']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['e']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['e']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['e']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['e']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['e']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['e']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['e']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['e']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['e']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['e']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['e']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['e']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['e']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['e']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['e']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['e']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['e']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['e']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['e']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['e']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['e']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['e']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['e']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['e']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['e']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['e']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['e']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['e']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['e']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['e']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['e']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['e']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['e']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['e']['total']);
?> 
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'full_name') {?>
    <li>Please enter your full name!</li>
   <?php }?>
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'address') {?>
    <li>Please enter your address!</li>
   <?php }?>
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'city') {?>
    <li>Please enter your city!</li>
   <?php }?>
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'state') {?>
    <li>Please enter your state!</li>
   <?php }?>
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'zip') {?>
    <li>Please enter your zip!</li>
   <?php }?>
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'country') {?>
    <li>Please choose your country!</li>
   <?php }?>
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'username') {?>
    <li>Please enter valid username! It should contains English letters and digits only.</li>
   <?php }?>
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'username_exists') {?>
    <li>Sorry, such user already exists! Please try another username. </li>
   <?php }?>
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'email_exists') {?>
    <li>Sorry, such email already exists! Please try another email. </li>
   <?php }?> 
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'password') {?> 
    <li>Please enter a password!</li>
   <?php }?>
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'password_confirm') {?>
    <li>Please check your password!</li>
   <?php }?>
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'password_too_small') {?>
    <li>The password you provided is too small, please enter at least <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['min_user_password_length']);?>
 characters!</li>
   <?php }?> 
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'transaction_code') {?> 
    <li>Please enter the Transaction Code!</li>
   <?php }?> 
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'transaction_code_confirm') {?> 
    <li>Please check your Transaction Code!</li>
   <?php }?>
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'transaction_code_too_small') {?>
    <li>The Transaction Code you provided is too small, please enter at least <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['min_user_password_length']);?>
 characters!</li>
   <?php }?>
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'transaction_code_vs_password') {?> 
    <li>The Transaction Code should differ from the Password!</li>
   <?php }?>
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'egold') {?> 
    <li>Please enter your e-gold account number!</li>
   <?php }?>
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'invalid_perfectmoney_account') {?> 
    <li>Please enter USD PerfectMoney account number!</li>
   <?php }?>
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'email') {?> 
    <li>Please enter your e-mail!</li>
   <?php }?>
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'agree') {?>
    <li>You have to agree with the Terms and Conditions!</li>
   <?php }?>
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'turing_image') {?>
    <li>Enter the verification code as it is shown in the corresponding box.</li>
   <?php }?> 
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'no_upline') {?>
    <li>The system requires an upline to register. <?php if ($_smarty_tpl->tpl_vars['settings']->value['get_rand_ref']) {?>You have to be agreed to random one or found a referral link in the net.<?php }?></li>
   <?php }?> 
   <?php if ($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->getVariable('smarty')->value['section']['e']['index']] == 'ip_exists_in_database') {?>
    <li>Your IP already exists in our database. Sorry, but registration impossible.</li>
   <?php }?>

   <br> 
  <?php endfor; endif; ?>
  </ul>
 <?php }?> 
 
 



 <style> 
  .adjust2 , .adjust{
max-width:1000px !important;}
.adjust{
min-width:1000px !important;}

.one_h{
display:inline-flex;
max-width:60px;

margin-top:50px;
}.dropdown1{
margin-left:-100px;
font-family:poppins,sans-serif;
font-size:18px ;
margin-top:44px;
margin-bottom:50px;}
  
.new_log{


  background:url(images/login.jpg);
  background-size:cover;
  background-repeat: no-repeat;border-radius:3px;
}

.new_log{
margin-top:30px;
margin-bottom:100px;
box-shadow: -1px 1px 10px -3px rgba(0,0,0,0.75);
-webkit-box-shadow: -1px 1px 10px -3px rgba(0,0,0,0.75);
-moz-box-shadow: -1px 1px 10px -3px rgba(0,0,0,0.75);
border-radius:3px;


}
.left_side{
padding-left:0px;
margin-left:0px !important;
background-color:white;
padding-top:50px;

border-radius:3px;}



.heading{
font-family:poppins,sans-serif;
font-size:34px;
color:gray;
font-weight:600;
margin-bottom:-10px;
}
.headingp{
 
font-size:18px;

color:gray;
margin-bottom:40px;


}
.input_email{
margin-top:30px;

}
.input_email .lable  
 {
font-size:18px;
color:#19BA99;

width:320px;
}

 .input_password .lable
{
font-size:18px;
color:#19BA99;

width:300px;
padding-left:58px;
}

.input_cpassword_reg{
  margin-top:20px;
  margin-bottom:20px;
}

 input{
border:none;
line-height: 50px;
padding-left:20px   ;

outline:none;}
.cpassword            {
font-size:16px !important;
border:1px solid !important;
border-color:#17B897 !important;
border-radius:3px;
width:340px !important;

padding-left:10px;


margin:auto;}
.hdformstyle{
  font-size:16px !important;
  border:none;
line-height: 50px;
padding-left:20px   ;



}

.gp5{
font-size:16px;
color:gray;
}
.gp5 a{
color:#17b897;}
.gp5 a:hover{
color:#17b897;}
.gp5 input{

zoom:1.5;
position:absolute;
margin-left:-25px !important;}



.group_reg .cpassword{
margin-top:30px;
margin-bottom:20px;
border:2px solid  #17B897;
    width:340px !impotrtant;
}


    
i{
color:#17B897;}

 .register{
border:none;
outline:none;
padding:10px 125px;
display:block;
margin: 30px auto 30px auto;
font-size:16px;
border-radius:3px;
color:white;
font-weight:600;
background-color:#17B897;
border-bottom: 2px solid #17B897 ;
}
.register:hover{
  border-bottom:2px solid gray;
  border-radius:3px;
}
.left_side .for_pass{
margin-top:30px;
font-size:16px;
color:#17B897;
border-bottom:2px solid;


}

.link2:hover{
color:#17b897;
background-color:white;
border:transparent;
text-decoration:none;
border-radius:3px;}
.group1{
margin-left:810px;
margin-top:-300px;
width:320px;
}
.text2{
color:white;
font-size:18px;
margin-bottom:40px;}
.link2{
margin:20px 40px;
margin-top:40px !important;
color:white;
font-size:18px;
border:2px solid;
border-color:#17B897;
padding: 10px 20px;}


.link_log:hover{
color:#17b897;
background-color:white;
border:transparent;
text-decoration:none;
border-radius:3px;}
.group4{
margin-left:980px;
margin-top:-650px;
margin-bottom:540px;
width:320px;
}
.text4{
color:white;
font-size:18px;
margin-bottom:40px;}
.link_log{
margin:20px 50px;
margin-top:40px !important;
color:white;
font-size:18px;
border:2px solid;
border-color:#17B897;
padding: 10px 20px;}

.lable_p{
margin-left:-200px;
padding-top:10px;
color:gray}
.lable_p i {
margin-right:20px;}


.pl{color:gray;
margin-left:90px;
margin-top:-46px;
margin-bottom:20px;
background:none;}
.inpts{
margin-top:-10px;
margin-bottom:10px;
}
.container{
  min-width:1200px;
}

.hdcont1{
margin-top:-70px;background-color:#19BA99;
padding:50px 0px 70px;}



.hdcont{
margin-top:25px;
margin-bottom:10px;
padding-top:30px;
padding-bottom:80px;
background: #149b80; /* Old browsers */
background: -moz-linear-gradient(-45deg, #149b80 0%, #44bf92 100%); /* FF3.6-15 */
background: -webkit-linear-gradient(-45deg, #149b80 0%,#44bf92 100%); /* Chrome10-25,Safari5.1-6 */
background: linear-gradient(135deg, #149b80 0%,#44bf92 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */}

.sp1{
min-width:900px !important;}
.group4{
margin-left:870px !important;}

.hdcont {
display:none;
}
.scrollbar{
background:#17B897 !important;
}
header {
margin-bottom:70px !important;
}
#group4{
margin-left:960px !important;}




	

 </style>
 
</div>  
 <div class="hdcont1">
 <div class="container new_log">
  <div class="row">
    <div class="col-lg-6  text-center left_side">

	
	
	<div class="group_reg">
	    <p class="heading">REGISTER</p></div> 
	<form method=post onsubmit="return checkform()"  name="regform">
	<input type=hidden name=a value="signup">
	<input type=hidden name=action value="signup">
	
	
		<p class="headingp ">Create your account now</p>
			
			
			<?php if ($_smarty_tpl->tpl_vars['settings']->value['use_user_location']) {?>
        	
        	 <div class="input_cpassword_reg"> 				<div class="cpassword"> <p class="rps"> <i class="fa fa-building" aria-hidden="true"></i>			
        	 <input type=text name=address value="<?php echo smarty_modifier_myescape(preg_replace("%(?<!\\\\)'%", "\'",$_smarty_tpl->tpl_vars['frm']->value['address']));?>
"  placeholder=" Your Address"class=hdformstyle size=30> </p></div> 			</div>
        
        	 <div class="input_cpassword_reg"> 				<div class="cpassword"> <i class="fa fa-map-signs" aria-hidden="true"></i> 			
        	 <input type=text name=city value="<?php echo smarty_modifier_myescape(preg_replace("%(?<!\\\\)'%", "\'",$_smarty_tpl->tpl_vars['frm']->value['city']));?>
"  placeholder="Your City "   class=hdformstyle size=30></div> 			</div>
        	
        	
        	 <div class="input_cpassword_reg"> 				<div class="cpassword"> 	<i class="fa fa-building" aria-hidden="true"></i>			
        	 <input type=text name=state value="<?php echo smarty_modifier_myescape(preg_replace("%(?<!\\\\)'%", "\'",$_smarty_tpl->tpl_vars['frm']->value['state']));?>
" placeholder="Your State"  class=hdformstyle size=30></div> 			</div>
           <div class="input_cpassword_reg">        <div class="cpassword"> 
        	<i class="fa fa-money" aria-hidden="true"></i>
        	 <input type=text name=zip value="<?php echo smarty_modifier_myescape(preg_replace("%(?<!\\\\)'%", "\'",$_smarty_tpl->tpl_vars['frm']->value['zip']));?>
" placeholder="Your Zip"  class=hdformstyle size=30></div> 			</div>
        	
        	
        	 <div class="input_cpassword_reg"> 				<div class="cpassword"> 				
        	 
        	  <select name='country' class=hdformstyle>
        	<option value=''>Country</option>
        	<?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['c'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['c']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['c']['name'] = 'c';
$_smarty_tpl->tpl_vars['smarty']->value['section']['c']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['countries']->value) ? count($_loop) : max(0, (int) $_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['c']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['c']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['c']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['c']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['c']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['c']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['c']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['c']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['c']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['c']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['c']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['c']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['c']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['c']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['c']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['c']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['c']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['c']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['c']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['c']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['c']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['c']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['c']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['c']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['c']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['c']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['c']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['c']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['c']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['c']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['c']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['c']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['c']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['c']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['c']['total']);
?>
        	<option <?php if ($_smarty_tpl->tpl_vars['countries']->value[$_smarty_tpl->getVariable('smarty')->value['section']['c']['index']]['name'] == $_smarty_tpl->tpl_vars['frm']->value['country']) {?>selected<?php }?>><?php echo smarty_modifier_myescape(preg_replace("%(?<!\\\\)'%", "\'",$_smarty_tpl->tpl_vars['countries']->value[$_smarty_tpl->getVariable('smarty')->value['section']['c']['index']]['name']));?>
</option>
        	<?php endfor; endif; ?>
        	  </td>
        	
        	<?php }?>
        
        	<?php if ($_smarty_tpl->tpl_vars['settings']->value['use_transaction_code']) {?>
        	
        	 <div class="input_cpassword_reg"> 				<div class="cpassword"> 	<i class="fa fa-money" aria-hidden="true"></i>		
        	 <input type=password name=transaction_code value="<?php echo smarty_modifier_myescape(preg_replace("%(?<!\\\\)'%", "\'",$_smarty_tpl->tpl_vars['frm']->value['transaction_code']));?>
" placeholder="Define Transaction Code"  class=hdformstyle size=30></div> 			</div>
        	
        	 <div class="input_cpassword_reg"> 				<div class="cpassword"> <i class="fa fa-money" aria-hidden="true"></i>		
        	 <input type=password name=transaction_code2 value="<?php echo smarty_modifier_myescape(preg_replace("%(?<!\\\\)'%", "\'",$_smarty_tpl->tpl_vars['frm']->value['transaction_code2']));?>
" placeholder="Retype Transaction Code" class=hdformstyle size=30></div> 			</div>
        	
        	<?php }?>
        
        
        	
        	 <div class="input_cpassword_reg"> 				<div class="cpassword"> <i class="fa fa-user" aria-hidden="true"></i> 				
        	 <input type=text name=fullname value="<?php echo smarty_modifier_myescape(preg_replace("%(?<!\\\\)'%", "\'",$_smarty_tpl->tpl_vars['frm']->value['fullname']));?>
" placeholder="Full Name"   class=hdformstyle size=30>
        	</div> 			</div>
        
        	 <div class="input_cpassword_reg"> 				<div class="cpassword"> <i class="fa fa-user" aria-hidden="true"></i>				
        	 <input type=text name=username value="<?php echo smarty_modifier_myescape(preg_replace("%(?<!\\\\)'%", "\'",$_smarty_tpl->tpl_vars['frm']->value['username']));?>
"   placeholder="Username" class=hdformstyle size=30>
        	</div> 			</div>
        	
        	
        	 <div class="input_cpassword_reg"> 				<div class="cpassword"> 	<i class="fa fa-lock" aria-hidden="true"></i>			
        	 <input type=password name=password value="<?php echo smarty_modifier_myescape(preg_replace("%(?<!\\\\)'%", "\'",$_smarty_tpl->tpl_vars['frm']->value['password']));?>
"  placeholder="Password" class=hdformstyle size=30>
        	</div> 			</div>
        
        	 <div class="input_cpassword_reg"> 				<div class="cpassword"> <i class="fa fa-lock" aria-hidden="true"></i>				
        	 <input type=password name=password2 value="<?php echo smarty_modifier_myescape(preg_replace("%(?<!\\\\)'%", "\'",$_smarty_tpl->tpl_vars['frm']->value['password2']));?>
"  placeholder="Retype Password"   class=hdformstyle size=30>
        	</div> 			</div>
        	
        
        
        	
        	 <div class="input_cpassword_reg"> 				<div class="cpassword"><i class="fa fa-envelope" aria-hidden="true"></i> 				
        	 <input type=text name=email value="<?php echo smarty_modifier_myescape(preg_replace("%(?<!\\\\)'%", "\'",$_smarty_tpl->tpl_vars['frm']->value['email']));?>
"  placeholder="E-mail Address"  class=hdformstyle size=30>
        	</div> 			</div>
        
        	 <div class="input_cpassword_reg"> 				<div class="cpassword"> 	<i class="fa fa-envelope" aria-hidden="true"></i>		
        	 <input type=text name=email1 value="<?php echo smarty_modifier_myescape(preg_replace("%(?<!\\\\)'%", "\'",$_smarty_tpl->tpl_vars['frm']->value['email1']));?>
" placeholder="Retype E-mail"  class=hdformstyle size=30>
        	</div> 			</div>
        	
        	
        	 <div class="input_cpassword_reg"> 				<div class="cpassword"> 			<i class="fa fa-user-secret" aria-hidden="true"></i>
        	 <input type=text name=sq value="<?php echo smarty_modifier_myescape(preg_replace("%(?<!\\\\)'%", "\'",$_smarty_tpl->tpl_vars['frm']->value['sq']));?>
"   placeholder="Secret Question" class=hdformstyle size=30>
        	</div> 			</div>
        
        	 <div class="input_cpassword_reg"> 				<div class="cpassword"> 	<i class="fa fa-shield" aria-hidden="true"></i>		
        	 <input type=text name=sa value="<?php echo smarty_modifier_myescape(preg_replace("%(?<!\\\\)'%", "\'",$_smarty_tpl->tpl_vars['frm']->value['sa']));?>
"  placeholder="Secret Answer" class=hdformstyle size=30>
        	</div> 			</div>
        	
        
        
        	<?php
$_from = $_smarty_tpl->tpl_vars['pay_accounts']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['ps'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['ps']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['ps']->value) {
$_smarty_tpl->tpl_vars['ps']->_loop = true;
$foreach_ps_Sav = $_smarty_tpl->tpl_vars['ps'];
?>
        	
        	 <div class="input_cpassword_reg"> 				<div class="cpassword"> 				<div class="lable_p"> <i class="fa fa-suitcase"></i></i>   Wallet</div>
        	 <input type=text class=inpts size=30 name=pay_account[<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ps']->value['id']);?>
] class=hdformstylevalue="<?php echo smarty_modifier_myescape(htmlspecialchars($_smarty_tpl->tpl_vars['ps']->value['account'], ENT_QUOTES, 'UTF-8', true));?>
" data-validate="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ps']->value['validate']['func']);?>
" data-validate-<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ps']->value['validate']['func']);?>
="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ps']->value['validate'][$_smarty_tpl->tpl_vars['ps']->value['validate']['func']]);?>
" data-validate-notice="<?php echo smarty_modifier_myescape(htmlspecialchars($_smarty_tpl->tpl_vars['ps']->value['validate']['notification'], ENT_QUOTES, 'UTF-8', true));?>
" placeholder="<?php echo smarty_modifier_myescape(htmlspecialchars($_smarty_tpl->tpl_vars['ps']->value['validate']['placeholder'], ENT_QUOTES, 'UTF-8', true));?>
 " ><p class="pl">  -"<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ps']->value['name']);?>
"</p>
            </div></div>
        	
        	<?php
$_smarty_tpl->tpl_vars['ps'] = $foreach_ps_Sav;
}
?>
        	<?php
$_from = $_smarty_tpl->tpl_vars['mpay_accounts']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['p'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['p']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['p']->value) {
$_smarty_tpl->tpl_vars['p']->_loop = true;
$foreach_p_Sav = $_smarty_tpl->tpl_vars['p'];
?>
        	<?php
$_from = $_smarty_tpl->tpl_vars['p']->value['accounts'];
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['ps'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['ps']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['ps']->value) {
$_smarty_tpl->tpl_vars['ps']->_loop = true;
$foreach_ps_Sav = $_smarty_tpl->tpl_vars['ps'];
?>
        	
        	 <div class="input_cpassword_reg"> 				<div class="cpassword"> 				<p class="lable_p">Your <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['p']->value['name']);?>
 <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ps']->value['name']);?>
</p>
        	 <input type=text class=inpts size=30 class=hdformstyle name="pay_account[<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['p']->value['id']);?>
][<?php echo smarty_modifier_myescape(htmlspecialchars($_smarty_tpl->tpl_vars['ps']->value['name'], ENT_QUOTES, 'UTF-8', true));?>
]" value="<?php echo smarty_modifier_myescape(htmlspecialchars($_smarty_tpl->tpl_vars['ps']->value['value'], ENT_QUOTES, 'UTF-8', true));?>
">
        	 </div></div>
        	
        	<?php
$_smarty_tpl->tpl_vars['ps'] = $foreach_ps_Sav;
}
?>
        	<?php
$_smarty_tpl->tpl_vars['p'] = $foreach_p_Sav;
}
?>
        
        
        	<?php if ($_smarty_tpl->tpl_vars['settings']->value['use_referal_program']) {?>
        	<?php if ($_smarty_tpl->tpl_vars['referer']->value) {?>
        	
        	 <div class="input_cpassword_reg"> 				<div class="cpassword"> 				<p class="lable_p">Your Upline</p>
        	 <input type=text disabled="disabled" name=sa value="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['referer']->value['name']);?>
 (<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['referer']->value['username']);?>
 )" class=hdformstyle size=30>
        	  </div> 			</div>
        	
        	<?php } else { ?>
        	<?php if ($_smarty_tpl->tpl_vars['settings']->value['force_upline']) {?>
        	 <?php if ($_smarty_tpl->tpl_vars['settings']->value['get_rand_ref']) {?>
        	  
        	   <td colspan=2>
        		You do not have an upline. Our system requires an upline for each user. You will have to agree to get a random one or find a referral link on the net.
        		<input type=checkbox name="rand_ref" value=1>
        	   </td>
        	  
        	 <?php } else { ?>
        	  
        	   <td colspan=2>
        		You do not have an upline. Our system requires an upline for each user.
        	   </td>
        	  
        	 <?php }?>
        	<?php }?>
        	<?php }?>
        	<?php }?>
        	<?php if ($_smarty_tpl->tpl_vars['userinfo']->value['validation_enabled'] == 1) {?>
        	
        	 <td class=menutxt align=right><img src="<?php echo smarty_modifier_myescape(encurl("?a=show_validation_image&".((string)$_smarty_tpl->tpl_vars['userinfo']->value['session_name'])."=".((string)$_smarty_tpl->tpl_vars['userinfo']->value['session_id'])."&rand=".((string)$_smarty_tpl->tpl_vars['userinfo']->value['rand'])));?>
"></td>
        	 <td><input type=text name=validation_number class=hdformstyle size=15></td>
        	
        	<?php }?>
			
			
			<div class="group5">
		<p class ="gp5">	<input type=checkbox name=agree value=1 <?php if ($_smarty_tpl->tpl_vars['frm']->value['agree']) {?>checked<?php }?> ><span> I agree with <a href="<?php echo smarty_modifier_myescape(encurl("?a=rules"));?>
">Terms and conditions</a></span></p>
			</div>
			
			
			<?php if ($_smarty_tpl->tpl_vars['ti']->value['check']['signup']) {?>
            <tr>
             <td class=menutxt align=right><img src="<?php echo smarty_modifier_myescape(encurl("?a=show_validation_image&".((string)$_smarty_tpl->tpl_vars['ti']->value['session']['name'])."=".((string)$_smarty_tpl->tpl_vars['ti']->value['session']['id'])."&rand=".((string)$_smarty_tpl->tpl_vars['ti']->value['session']['rand'])));?>
"></td>
             <td><input type=text name=validation_number class=inpts size=15></td>
            </tr>
            <?php }?>
            

			<button type="submit" class="register" >REGISTER</button></select></div></div></form></div></div>
			
			<div class="group4" id ="group4">
			<p class="text4">Already have an account?</p><a href="" class="link_log">LOG IN</a> 
</div></div></div>
</div>
 
<?php }?>


<div><?php echo $_smarty_tpl->getSubTemplate ("hustydesigns_framework/footer_home.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>