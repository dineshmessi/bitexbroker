<?php /* Smarty version 3.1.27, created on 2019-11-27 18:34:25
         compiled from "/home/h27610/public_html/tmpl/faq.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:810897265ddec1b1060c08_03685092%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7d1e99d61b1e8ad062148607e51297bcfe421814' => 
    array (
      0 => '/home/h27610/public_html/tmpl/faq.tpl',
      1 => 1574753639,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '810897265ddec1b1060c08_03685092',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5ddec1b10ec637_65345623',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5ddec1b10ec637_65345623')) {
function content_5ddec1b10ec637_65345623 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '810897265ddec1b1060c08_03685092';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>




<style>
.hdcont h3:first-of-type {
margin-bottom:30px !important;
}
.tab {
width:280px !important;
height:auto !important;
text-align:center;
display:inline-block !important;
vertical-align:top;
margin-right:25px;
margin-top:0px;
background:#17b897 !important;
border-radius:3px;
}
.faq_main_title   {
color: #fff;
background:none;
font-size: 13px;
padding:15px 25px;
width:100%;
display:block;
margin:10px 0 0 0px;
border:1.5px solid #fff;
border-radius:3px;
cursor:pointer;
font-weight:600;
outline:none;
}
.faq_main_title.active {
background:#fff;
color:#000 !important;
border-color:#fff;
outline:none;
}
.tab-answers {
width:820px;
background:#fff;
display:inline-block;
vertical-align:top;
margin-top:00px;
padding:20px 25px;
border-radius:3px;
}
.faq_title   {
padding:0 0 15px 0;
border-radius:0px;
background:none;
font-size: 14px;
color: #17b897;
font-weight:600;
border-radius:0px;
margin-bottom:-5px;
}
.faq_title:before   {
content:'Q -';
margin-right:10px;
font-size:25px;
position:relative;
top:4px;
color:#17b897;
}
.faq_body {
border-radius:0px;
border-bottom:1px solid #ccc;
padding:0px 20px 30px 0 ;
background:#fff;
font-size: 13px;
color: #444;

font-weight:400;
line-height:20px;
margin:5px 0 20px 0;
border-radius:3px;
}
.tabcontent {
display:none;
}
.activecontent {
display:block;
}
</style>
<?php echo '<script'; ?>
>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
<?php echo '</script'; ?>
>





<h3>Frequently Asked Questions</h3>

<div class="HD_faq">
    
    <div class="tab">
        <button class="faq_main_title tablinks active" onclick="openCity(event, 'general_questions')">GENERAL QUESTIONS</button>
        <button class="faq_main_title tablinks" onclick="openCity(event, 'account_questions')">ACCOUNT QUESTIONS</button>
        <button class="faq_main_title tablinks" onclick="openCity(event, 'investment_questions')">INVESTMENT QUESTIONS</button>
        <button class="faq_main_title tablinks" onclick="openCity(event, 'withdrawal_questions')">WITHDRAWAL QUESTIONS</button>
        <button class="faq_main_title tablinks" onclick="openCity(event, 'affiliate_questions')">AFFILIATE QUESTIONS</button>
    </div>
	<div class="tab-answers">
		<div id="general_questions" class="faq_block tabcontent activecontent">

<div class="faq_title">Is Bitexbroker incorporated as a company?
</div><div class="faq_body">
Yes, Bitexbroker is a legal investment company incorporated in the United Kingdom with the registration No. 12000277  from 16 may 2019 and whose registered office is at 123 Minories, London, United Kingdom, EC3N 1NT 
</div>
<div class="faq_title">Who can participate in your program? Do you accept investors from all countries?
</div><div class="faq_body">
Any individual or corporation from any country may open an account with us and we are happy to accept investors from any place in the world. The only condition is accepting our terms of service.
</div>
<div class="faq_title">How is safe the company's website?
</div><div class="faq_body">
We are using the strongest DDoS protection in the industry with 100% up-time guarantee. Transfer information from and to our website is realized and ciphered by SSL Encryption. Furthermore, additional software layers are installed to ensure fast and secure operation of the project.
</div>
<div class="faq_title">Who manages the investment portfolio?
</div><div class="faq_body">
The investment portfolio is managed by our team of financial specialists with strong command in finance allows for effective analysis of the market and financial situation. The Company employs experts on the full-time basis who have been working on the currency exchange market for more than 10 years on average. Our financial team also includes specialists who are experts in evaluating new private businesses called start-ups which have most chances to grow into large-scale and highly profitable enterprises.
</div>
<div class="faq_title">Can I register several accounts in your program?
</div><div class="faq_body">
No, you can create only one account from one computer (ip). If we find out you have multiple accounts, all of them will be frozen and the funds forfeited without any notice.
</div>
<div class="faq_title">Which e-currencies do you accept?
</div><div class="faq_body">
Today all transactions on the financial markets are performed at high speeds to save time, so financial transactions carried out via the Internet also require high speed. That is why most financial transactions related with investments are performed in electronic currencies, namely - Perfect Money, Payeer, Bitcoin, Bitcoin Cash, Litecoin, Ethereum.
</div>
<div class="faq_title">Do you charge any fee for providing your investment services?
</div><div class="faq_body">
No, we do not charge any fee.
</div>

		</div>
		
		<div id="account_questions" class="faq_block tabcontent">
			
<div class="faq_title">How can I access the account?
</div><div class="faq_body">
If you are a registered user of Bitexbroker, please enter your username and password in the appropriate fields at the top of the website and click the 'Login to Account' button. You will be redirected to your account automatically as soon as you have done the above.

</div><div class="faq_title">What if I can't access my account because I forgot my password?
</div><div class="faq_body">
Click on forgot password link, enter your username or e-mail and follow instruction. You'll receive your account information by email.

</div><div class="faq_title">How can I change my e-mail address or password?
</div><div class="faq_body">
Log into your Elixbit account and click on the 'Edit Account'. You can change your password there. Unfortunately, you cannot change your e-mail address by yourself because of security reasons, if you need to do this, please contact our customer service representatives


</div><div class="faq_title">I can't log in into my account. What could cause this problem?
</div><div class="faq_body">
Sometimes problems of this kind are caused by errors of your web browser. There is no reason to worry, you just need to wait a few minutes and then try to log in again. First of all, you need to clean the cache of your web browser. If the problem persists, please contact our customer service representatives.


</div><div class="faq_title">How frequently are you updating my account?
</div><div class="faq_body">

We update your account every second and you can access the member area 24 hours a day, 365 days a year over the internet and keep track on all of your account actions.

</div><div class="faq_title">How do I know the history of my transactions?
</div><div class="faq_body">
Enter the member area and you can check history of your account transactions there.


</div><div class="faq_title">Will you cancel account without deposit?
</div><div class="faq_body">
No, your account will not be cancelled without deposit, unless you ask us to do.
		</div>
		</div>
		
		
		<div id="investment_questions" class="faq_block tabcontent">

<div class="faq_title">How long will it take to add deposit amount into my account?
</div><div class="faq_body">
Your account will be updated immediately as you deposit, in a minute. For Bitcoin deposits you should send actual amount to shown Bitcoin wallet, because Bitcoin network is not instant so your deposit time can take from a 15 minutes up to 24 hours.

</div><div class="faq_title">What is the minimum and maximum amount of deposit?
</div><div class="faq_body">
The minimum investment amount is only $30 and the maximum amount is $100,000.

</div><div class="faq_title">Can I make additional investments at any time?
</div><div class="faq_body">
Yes, there is no limitation. You can make as many deposits as you want.

</div><div class="faq_title">Are additional deposits into the same account processed separately or they are simply added to the current principal?
</div><div class="faq_body">
Additional deposits into an account will be processed separately. It is not possible to merge one of your investment with another one.

</div><div class="faq_title">Can I deposit directly from my account balance?
</div><div class="faq_body">
You can make a deposit from your account balance. Simply log into your member account, click 'Make Deposit' and select 'Deposit' from 'Account Balance' button.

</div><div class="faq_title">Can I have several individual deposits, made by various payment methods?
</div><div class="faq_body">
Yes, you can make as many deposits as you want through different payment systems.
</div>

		</div>
		
		<div id="withdrawal_questions" class="faq_block tabcontent">    
			<div class="faq_title">After I make a withdrawal request, when will my withdrawal request be processed?
</div><div class="faq_body">
Your withdrawal request will be processed within 24 hours.

</div><div class="faq_title">What is the minimum and maximum amount that can be withdrawn?
</div><div class="faq_body">
The minimum withdrawal amount is only $0.10 and the maximum amount is not limited.

</div><div class="faq_title">When can I withdraw funds from available balance?
</div><div class="faq_body">
You can withdraw funds from your available balance anytime you want and without any fee.

</div><div class="faq_title">Can there be delays on a withdrawal request?
</div><div class="faq_body">
The delay of a withdrawal sometimes can happen for an unstable operation of payment systems or some maintenance work on the website. In such case the website administration has to wait for normalization of the situation and only then may pay out. It can take several hours up to 2-3 days; therefore, we encourage you to be tolerant. In case of a long pause we will inform on all current conditions by means of our forms of communication.

</div><div class="faq_title">Can I add funds in one e-currency and withdraw from the other?
</div><div class="faq_body">
You can withdrawal funds only in the way that has been used for depositing funds.

</div><div class="faq_title">Do you process withdrawal requests on weekends?
</div><div class="faq_body">
Yes, we process withdrawal requests 7 days a week.
</div>
		</div>
		
		<div id="affiliate_questions" class="faq_block tabcontent">    
			<div class="faq_title">Do you have an affiliate program?
</div><div class="faq_body">
Yes, we do. It is a great way to earn substantial income! All you need to do is to attract new investors to our investment program using your personal referral link. The referral program uses multilevel referral commission which will pay 5% from each deposit of level 1 referrals, 2% from each deposit made by your level 2 referrals (people referred by your direct invitees) and 1% of each deposit made by your level 3 referrals (i. e. people referred by your level 2 invitees).

</div><div class="faq_title">How do I get my referral link, view the total number of referrals and referral materials such as banners?
</div><div class="faq_body">
Your referral link is created automatically when you open an account. You can find referral link in your main account menu and our banners on the 'Referral links' page. Also, you will find everything related to your referrals such as total number of referrals, active referrals, etc.

</div><div class="faq_title">When will referral commission be added to my account balance?
</div><div class="faq_body">
The referral commission is accrued to your account balance immediately after your referral make a deposit. The referral bonus can only be withdrawn in the e-currency which your referral used to make their deposit, for example, if your referral used Perfect Money to deposit, then you may only withdraw your referral bonus in Perfect Money.

</div><div class="faq_title">How do you know that a new investor was introduced by me?
</div><div class="faq_body">
The referral system works during registration and is fully automatic. If an investor signs up via your referral link, the system will treat that investor as your referral.

</div><div class="faq_title">Is there any limitation in the amount of referral commission?
</div><div class="faq_body">
No, there is no limit. Therefore, the more your referrals invest, the more you can earn.
</div>
		</div>
	</div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>