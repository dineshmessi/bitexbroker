<?php /* Smarty version 3.1.27, created on 2019-11-27 09:34:18
         compiled from "my:_emailbody_registration" */ ?>
<?php
/*%%SmartyHeaderCode:15313764825dde431a962c31_37189563%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '349257fbad92bd38ac33c718b057c126817b92e6' => 
    array (
      0 => 'my:_emailbody_registration',
      1 => 1574847258,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '15313764825dde431a962c31_37189563',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5dde431a9a6a24_16330063',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5dde431a9a6a24_16330063')) {
function content_5dde431a9a6a24_16330063 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '15313764825dde431a962c31_37189563';
?>
Hello #name#,

Thank you for registration on our site.

Your login information:

Login: #username#
Password: #password#

You can login here: #site_url#

Contact us immediately if you did not authorize this registration.

Thank you.<?php }
}
?>