<?php /* Smarty version 3.1.27, created on 2019-11-27 20:46:38
         compiled from "/home/h27610/public_html/tmpl/index_last_withdrawals.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:16554859585ddee0ae5a0d32_78670631%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7b102258f82087dcb72fbf79d0881fe9a26fe0c9' => 
    array (
      0 => '/home/h27610/public_html/tmpl/index_last_withdrawals.tpl',
      1 => 1574753639,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16554859585ddee0ae5a0d32_78670631',
  'variables' => 
  array (
    'last_withdrawals' => 0,
    's' => 0,
    'currency_sign' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5ddee0ae5adb96_60657089',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5ddee0ae5adb96_60657089')) {
function content_5ddee0ae5adb96_60657089 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/h27610/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '16554859585ddee0ae5a0d32_78670631';
if ($_smarty_tpl->tpl_vars['last_withdrawals']->value) {?>
<?php
$_from = $_smarty_tpl->tpl_vars['last_withdrawals']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['s'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['s']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['s']->value) {
$_smarty_tpl->tpl_vars['s']->_loop = true;
$foreach_s_Sav = $_smarty_tpl->tpl_vars['s'];
?>
<div class="hd1">

            <div class="h1 text-left">
              <ul>
              <li><p class="hp1"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['s']->value['username']);?>
:</p>
                <p class="hp2r   " style="color:#AA1927"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['s']->value['amount']);?>
</p></li>
                <li><img class="pn" src="images/<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['s']->value['ec']);?>
.png"></li>
             
              </ul>
            </div>
          </div>
 

<?php
$_smarty_tpl->tpl_vars['s'] = $foreach_s_Sav;
}
?>
<?php }
}
}
?>