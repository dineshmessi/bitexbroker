<?php /* Smarty version 3.1.27, created on 2019-11-27 20:26:43
         compiled from "/home/h27610/public_html/tmpl/hustydesigns_framework/header_dash.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:2528841285ddedc03396778_98072517%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b5e178e4b72f280414cbd8210f9d1afd7316dc66' => 
    array (
      0 => '/home/h27610/public_html/tmpl/hustydesigns_framework/header_dash.tpl',
      1 => 1574753639,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2528841285ddedc03396778_98072517',
  'variables' => 
  array (
    'settings' => 0,
    'userinfo' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5ddedc033c81d9_01523326',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5ddedc033c81d9_01523326')) {
function content_5ddedc033c81d9_01523326 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/h27610/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '2528841285ddedc03396778_98072517';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</title>
  
  
  <meta name="viewport" content="width=1400; user-scalable=1;" />

   
  <link href="images/favicon.png" rel="icon" />
 
    <link href="css/style.css" rel="stylesheet">
    <?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="js/bootstrap.min.js"><?php echo '</script'; ?>
>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"><?php echo '</script'; ?>
>
      
<!-- fonts link in the tab--->
<link href="https://fonts.googleapis.com/css?family=Bai+Jamjuree&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Bai+Jamjuree&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet">

 <?php echo '<script'; ?>
 type="text/javascript" src="js/js.js"><?php echo '</script'; ?>
>
 <link rel="stylesheet" type="text/css" href="../css/style.css">
<link rel="stylesheet" type="text/css" href="template/dashboard/style.css">
 <link rel="stylesheet" type="text/css" href="template/hdcustomcss.css">
</head>
<style >
   .one_h{
display:inline-block;
min-width:100px !important;
max-width:300px;

margin-top:60px !important;
}
.conty{
display:flex;
margin-top:-220px !important;
}
.navbar-toggler{

 margin-top:40px;
  margin-left:-200px;
}
.hd{
  margin-bottom: -10px;
}
.drop


.one_h li {
list-style-type:none;
padding:0px;
font-size:16px;
font-weight:400;
line-height:10px;
margin:0px;}


.o1l{
margin-top:-5px;
margin-left:20px;
margin-right:10px;}
.o2l{
margin-top:-10px;
margin-left:-5px;
margin-right:10px;
}
.o3l{
margin-top:-10px;
margin-right:10px;}

.dropdown1{
font-family:poppins,sans-serif;

margin-top:-174px;
margin-bottom:0px;
margin-left:-220px;
width:160px;}
.dropdown1 a{
font-size:12px;}
.pro{
margin-bottom:-220px;
max-height:220px;}
#navbarCollapse{
margin-top:-30px;
margin-left:280px;
margin-bottom:10px;
padding:0px;
}

.container .pro_hr{
margin-top:-220px;
margin-left:70px;
margin-bottom:60px;}
.navbar-toggler{
  margin-top:150px;
  margin-bottom:0px;
}
.nl1{
display:flex;
margin-top:-10px;
margin-left:0px;}
.pro{
  margin-bottom: -20px;
}

@media only screen and (min-width: 320px) and (max-width: 1060px){
  .dropdown1{
    margin-top:60px;margin-left:250px;    
    position: relative  ;
    z-index: 99;
  }
.container hr{
display:none !important;}


}
.navbar-brand{
margin-left:100px;}
.conty{
max-width:1000px;
margin-left:100px;}
.static-top{
max-width:1435px;
padding:0px;}
.dropdown-toggle{
  width: 160px;
}
 .dropdown1{
font-size:12px !important;
margin-left:-250px;}
.dropdown-toggle
{
font-size:12px !important;}
.nav-link{
width:90px !important;}
.nl1{
display:flex;
margin-top:-10px;
margin-left:-200px;}
.nl1 .nav-link{
width:100% !important;}



</style>
<body>
    <header class="static-top">

    <div class="container hd">
      <div class="pro static-top">
  
        <!-- logo content--->
          <a href="#" class="navbar-brand ">
          <img src="images/logo.jpg" class="  dglogo text-center  float-center ">
          </a> <div class="top">
            <div class="container"> 
            <div class="row conty">
              <div class="col-lg-4 one_h leo">
            
                      <li><img  class ="o1l"src="images/t1.png"></li>
                      <li class=""><p class="n1h">47 Old Gloucester Street</p>
                        <p class="n1h">London, England, </p>
                          <p class="n1h">WC1N 3AD.   </p></li>
                      </div>

                      <div class="col-lg-4 one_h">
                      <li><img class ="o2l" class ="o1l"src="images/t2.png"></li>
                      <li><p class="n1h">contact@bitexbroker.com</p>
                        <p class="n1h">  Phone Available For Vip</p></li>
                    </div>

                      <div class="col-lg-4  one_h">
                      <li><img  class="o3l"  src="images/t3.png"></li>
                      <li class=""><p class="n1h">Number :  12319735</p>
                        <p class="n1h"><a href="pdf/certificate.pdf" download>Download certificate</a></p></li>
               
                       </div>
                     </div>
                   </div>


                       <div class="dropdown1    ">


    <button class="btn  dropdown-toggle" type="button" data-toggle="dropdown"><span>English</span>
   </button>
    <ul class="dropdown-menu">
      <li><a href="#">Tamil</a></li>
      <li><a href="#">German</a></li>
      <li><a href="#">French</a></li>
    </ul>
  </div>

</div> </div>  <hr class="pro_hr">

      
   <nav class="navbar navbar-expand-lg navbar-light bg-none static-top ">
          <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
          <i class="fa fa-bars" style="color:#15B596"></i>
          </button>
          <!-- navigation headings--->

          <div class="collapse navbar-collapse static-top" id="navbarCollapse">
          <div class="navbar-nav  d-flex    ">
            <a href="<?php echo smarty_modifier_myescape(encurl("?a=home"));?>
" class="  btn nav-item n1 nav-link ">HOME</a>
            <a href="<?php echo smarty_modifier_myescape(encurl("?a=cust&page=invest"));?>
" class="btn  n2 nav-item nav-link ">INVESTMENT</a>             
            <a href="<?php echo smarty_modifier_myescape(encurl("?a=cust&page=about"));?>
" class="btn nav-item  n3 nav-link ">ABOUT US</a>
          
            <a href="<?php echo smarty_modifier_myescape(encurl("?a=faq"));?>
" class=" btn nav-item n4 nav-link">FAQs</a>
            <a href="<?php echo smarty_modifier_myescape(encurl("?a=support"));?>
" class=" btn nav-item n4 nav-link">CONTACT US</a>
            <a href="representative.php" class=" btn nav-item n4 nav-link">REPRESENTATIVE</a>

  <?php if ($_smarty_tpl->tpl_vars['userinfo']->value['logged'] != 1) {?>
  <div class="nl1">
            <a href="<?php echo smarty_modifier_myescape(encurl("?a=login"));?>
" class= "btn nav-item r1 nav-link "> LOGIN</a>
                  <a href="<?php echo smarty_modifier_myescape(encurl("?a=signup"));?>
" class= "btn  r2 nav-item nav-link "> CREATE ACCOUNT  </a>
                        <?php } else { ?>
                        <div class="nl1">
                         <a href="<?php echo smarty_modifier_myescape(encurl("?a=logout"));?>
" class= "btn nav-item r1 nav-link "> LOGOUT</a>
                        <a href="<?php echo smarty_modifier_myescape(encurl("?a=account"));?>
" class= "btn  r2 nav-item nav-link ">DASHBOARD  </a>
                      </div>

<?php }?>


</div>
</div>
    <div class="clerfix"></div>
  </nav></div></header>


  
  <style>
body {
margin:0;
padding:0;
}
.container {
min-width:1200px !important;
padding:0 !important;
}
.header {
background:url(images/topinnerbg.png);
background-size:cover;
position:static !important;
min-height:432px;
margin:0 !important;
padding:0 !important;
}

.navbar {
background:none !important;
border:none !important;
}
.toplink:hover {
    color:#f2f2f2 !important;
background:none !important;
border:none !important;
}
li {
list-style:none;
}
  </style>
    
  
<div class="ds container">	<div class="tophorizontamenu container_fluid">
				<div class="tophorizontamenucont">
					<a href="?a=account"><i class="fa fa-user"></i>&nbsp;Account</a>
					<a href="?a=deposit"><i class="fa fa-usd"></i>&nbsp;Start Investment</a>
					<a href="?a=deposit_list"><i class="fa fa-usd"></i>&nbsp;My Investments</a>
					<a href="?a=referallinks"><i class="fa fa-external-link-square"></i>&nbsp;Promo Tools</a>
					<a href="?a=withdraw"><i class="fa fa-caret-square-o-down"></i>&nbsp;Withdraw Earnings</a>
					<a href="?a=referals"><i class="fa fa-users"></i>&nbsp;My Referrals</a>
			
					
				</div>
			</div>
			</div>
		<div class="dashboardcont"><?php }
}
?>