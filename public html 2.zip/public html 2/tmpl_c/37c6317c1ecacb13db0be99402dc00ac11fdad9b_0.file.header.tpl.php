<?php /* Smarty version 3.1.27, created on 2019-11-27 20:46:38
         compiled from "/home/h27610/public_html/tmpl/header.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:17423598025ddee0ae4e7255_99554879%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '37c6317c1ecacb13db0be99402dc00ac11fdad9b' => 
    array (
      0 => '/home/h27610/public_html/tmpl/header.tpl',
      1 => 1574753693,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17423598025ddee0ae4e7255_99554879',
  'variables' => 
  array (
    'settings' => 0,
    'referer' => 0,
    'home' => 0,
    'homea' => 0,
    'ref' => 0,
    'userinfo' => 0,
    'membersidebar' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5ddee0ae5229e3_73005860',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5ddee0ae5229e3_73005860')) {
function content_5ddee0ae5229e3_73005860 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/h27610/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '17423598025ddee0ae4e7255_99554879';
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><title><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</title>

<!-- Predefined page conditions  -->
<?php $_smarty_tpl->tpl_vars['ref'] = new Smarty_Variable("/?ref=".((string)$_smarty_tpl->tpl_vars['referer']->value['username']), null, 0);?>
<?php $_smarty_tpl->tpl_vars['home'] = new Smarty_Variable("/", null, 0);?>
<?php $_smarty_tpl->tpl_vars['homea'] = new Smarty_Variable("/?a=home", null, 0);?>
<?php $_smarty_tpl->tpl_vars['logout'] = new Smarty_Variable("/?a=logout", null, 0);?>

<!-- Common headers to all type of pages -->
<link rel="stylesheet" href="./template/hd_animate.css">
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.icons8.com/fonts/line-awesome/1.1/css/line-awesome-font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css" />
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
 

<style>
.custom_scroller::-webkit-scrollbar-track
{
	-webkit-box-shadow: none;
	background-color: transparent;
}
.custom_scroller::-webkit-scrollbar
{
	width: 5px;
	background-color: transparent;
}
.custom_scroller::-webkit-scrollbar-thumb
{
	background-color: #1cba9f;
	border: 0px solid #1cba9f;
}
</style>



</head>

<body class="scrollbar custom_scroller">


<?php if ($_SERVER['REQUEST_URI'] == $_smarty_tpl->tpl_vars['home']->value || $_SERVER['REQUEST_URI'] == $_smarty_tpl->tpl_vars['homea']->value || $_SERVER['REQUEST_URI'] == $_smarty_tpl->tpl_vars['ref']->value) {?>


	<!-- Show homepage alone specific header -->
	<?php echo $_smarty_tpl->getSubTemplate ("hustydesigns_framework/header_home.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>
     

<?php } else { ?>
	
	<?php if ($_smarty_tpl->tpl_vars['userinfo']->value['logged'] == 1 && $_smarty_tpl->tpl_vars['membersidebar']->value != "yes") {?>
		
		<?php if ($_SERVER['REQUEST_URI'] == "/?a=support" || $_SERVER['REQUEST_URI'] == "/?a=news" || $_SERVER['REQUEST_URI'] == "/?a=faq" || $_SERVER['REQUEST_URI'] == "/?a=cust&page=invest" || $_SERVER['REQUEST_URI'] == "/?a=cust&page=affiliates" || $_SERVER['REQUEST_URI'] == "/?a=cust&page=about" || $_SERVER['REQUEST_URI'] == "/?a=cust&page=representatives" || $_SERVER['REQUEST_URI'] == "/?a=start" || $_SERVER['REQUEST_URI'] == "/?a=cust&page=bounty") {?>
			
			<!-- Show loggedin inner pages specific header -->
			<?php echo $_smarty_tpl->getSubTemplate ("hustydesigns_framework/header_inners.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>
 
			
		<?php } else { ?>
			
			<!-- Dashboard Header -->
			<?php echo $_smarty_tpl->getSubTemplate ("hustydesigns_framework/header_dash.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>
 
		
		<?php }?>
		
	<?php } else { ?>
	
		<!-- Not logged in inner pages Header -->
		<?php echo $_smarty_tpl->getSubTemplate ("hustydesigns_framework/header_inners.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>
 
	
	<?php }?>

<?php }
}
}
?>