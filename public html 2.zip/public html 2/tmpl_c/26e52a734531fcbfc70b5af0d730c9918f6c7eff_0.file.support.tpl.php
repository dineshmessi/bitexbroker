<?php /* Smarty version 3.1.27, created on 2019-11-27 20:32:59
         compiled from "/home/h27610/public_html/tmpl/support.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:86209855ddedd7b06b435_50268822%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '26e52a734531fcbfc70b5af0d730c9918f6c7eff' => 
    array (
      0 => '/home/h27610/public_html/tmpl/support.tpl',
      1 => 1574753903,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '86209855ddedd7b06b435_50268822',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5ddedd7b0b0518_90993473',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5ddedd7b0b0518_90993473')) {
function content_5ddedd7b0b0518_90993473 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '86209855ddedd7b06b435_50268822';
echo $_smarty_tpl->getSubTemplate ("hustydesigns_framework/header_inners.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<h3 class="first container text-center">Contact <span>us </span></h3>
<hr style="width:200px;border-top:2px solid gray;">


<style>

.table_left {
padding:0px;
width:100%;
height:400px;
margin:0px 0 0 0;
display:block;
}

.table_right{
width:100%;
margin:55px 0 0px 0 !important;
text-align:center;
}
.top_content {
display:inline-block;
min-height:450px;
width:450px;
margin:0px -8px 0 0;
padding:25px 25px;
vertical-align:top;
border-radius:5px;
margin-left:-10px;
text-align:center;
color:#000;
}
.platform_box {
border:0px solid #fff;
background:none;
padding:15px 0;
border-radius:3px;
color:#000;
text-align:left;
}
.platform_box{
border-bottom:1px solid #ddd;
}
.platbox {
margin:15px 0;
}
.platbox h6 {
font-size:16px;
margin-bottom:5px;
color:#17b897;
padding-left:65px;
font-weight:00 !important;
}
.platbox span {
display:block;
font-size:13px;
color:#000;
padding-left:65px;
font-weight:300 !important;

}
.platbox i {
position:absolute;
font-size:34px;
color:#17b897;
padding:0px 0 0 5px !important;
}
.platbox a {
color:#000;
}

/*Contact Fomr */
.contactmaincont {
display:inline-block;
min-height:450px;
width:450px;
background:#fff;
margin:0px 0px 0 0;
padding:25px 50px;
vertical-align:top;
border-radius:5px;
text-align:center;
color:#444;
box-shadow: 0px 0px 6px 0px rgba(0, 0, 0, 0.2);
-moz-box-shadow: 0px 0px 6px 0px rgba(0, 0, 0, 0.2);
-webkit-box-shadow: 0px 0px 6px 0px rgba(0, 0, 0, 0.2);
border:1px solid #ddd;

}

.formgtitler {background:#DFB964;padding:0px 25px;font-size:18px;font-weight:400;border-radius:3px;color:#444;}

.div_right span {display:block;padding:25px 15px;}
.formgrouper {text-align:left;font-weight:400;margin-top:0px;color:#444;}.formgrouper label {color:#444;font-weight:400 !important;margin:15px 5px 10px 0;display:block;}

.formgrouper input {
margin:10px 0 !important;
}

.swiper-container {
width:860px;
display:inline-block;
height:646px;
border-radius:3px;
margin-left:20px !important;
margin-top:50px !important;
}.swiper-pagination-progressbar-fill{
background-color:#19BA99 !important;}
.swiper-button-prev{
color:#19BA99 !important;}
input, textarea{padding:15px 30px;
width:340px;
margin-top:30px;
margin-bottom:30px !important;
font-family:poppins,sans-serif;
font-size:12px !important;
font-weight:500 !important;} 

.swipe-button-prev{
color:#19BA99 !important;}

textarea{
margin-bottom:10px !important;}

.sbmt{
margin-top:140px;
margin-bottom:-100px !important;
margin-left:-5px;
border:2px solid ;
border-color:#19BA99;
border-radius:5px;
outline:none;
background-color:white;}

.formgrouper label
{
margin-top:10px !important;

font-family:poppins,sans-serif;
font-size:12px !important;
color:gray !important;
font-weight:600px;
}.inpts{
margin-top:0px;}
iframe {
margin:0;
}
.foot {
margin:0 !important
}
.first{
font-family:poppins,sans-serif;
color:gray;
font-size:34px;}
.first span{
color:#17B897;
font-size:38px;
font-weight:700;}


.sbmt{
margin-top:25px !important;
margin-bottom:-100px !important;
margin-left:-5px;
border:2px solid ;
border-color:#19BA99;
border-radius:5px;
outline:none;
background-color:white;}
.sbmt{
background-color:#17B897 !important;
color:white !important;}
.first{
	border:none !important;
}


</style>



<div class="contact_container">	

	
	<div class="table_right">
		
		<div class="top_content">		
			<div class="platform_box">
			
				<div class="platbox">
					<i class="material-icons">room</i>
					<h6>Address</h6>
					<span>

47 Old Gloucester Street<br>

London, England,<br>

WC1N 3AD.					<br><b>Available only for VIP</b>	
					</span>				
					<h6>Opening hours</h6> <span>Monday - Friday  <br> 10-18 (GMT)</span>
				
				</div>
				
			</div>
			<div class="platform_box">
				
				<div class="platbox">
					<i class="material-icons">question_answer</i>
					<h6>Email Address</h6>
					<span>
						contact@bitexbroker.com
					</span>
				</div>
				<div class="platbox">
					<i class="material-icons">account_balance</i>
					<h6>Campany Details</h6>
					<span>
						<a href="https://beta.companieshouse.gov.uk/company/12069076" target="blank">Company #12319735</a>
					</span>
				</div>
				
			</div>
			
		</div>
		
		<div class="contactmaincont">
						<?php echo '<script'; ?>
 language=javascript>
				function checkform() {  if (document.mainform.name.value == '') {    alert("Please type your full name!");    document.mainform.name.focus();    return false;  }  if (document.mainform.email.value == '') {    alert("Please enter your e-mail address!");    document.mainform.email.focus();    return false;  } if (document.mainform.message.value == '') {    alert("Please type your message!");    document.mainform.message.focus();    return false;  }  return true;}		<?php echo '</script'; ?>
>

			<form method=post name=mainform onsubmit="return checkform()"><input type="hidden" name="form_id" value="15712025262240"><input type="hidden" name="form_token" value="e53c008fe9bac0df3aede3bac4bf78ca">
			<input type=hidden name=a value=support>
			<input type=hidden name=action value=send>
						<div class="formgrouper">
				<label></label>
								<input placeholder="Your Name" type="text" name="name" value="" size=30 class=inpts>			
					
			</div>
			<div class="formgrouper">
								<input placeholder="Your Email" type="text" name="email" value="" size=30 class=inpts>
					
			</div>		
			
			<div class="formgrouper">
				<label>Message</label>
				<textarea name=message placeholder="enter your message" class=inpts cols=45 rows=4></textarea>
			</div>
			<div class="formgrouper">
							</div>
			<input type=submit value="Send" class=sbmt></form>		</div>
		
		<div class="swiper-container"  id="swiper1">
			<!-- Additional required wrapper -->
			<div class="swiper-wrapper">
			  
				<div class="swiper-slide circle">
							<img border=0 width="100%" height="100%" alt="" src="tmplimg/1.jpg">
						</div>
						<div class="swiper-slide circle">
							<img border=0 width="100%" height="100%" alt="" src="tmplimg/2.jpg">
						</div>
						<div class="swiper-slide circle">
							<img border=0 width="100%" height="100%" alt="" src="tmplimg/3.jpg">
						</div>
						
			</div>
			 <!-- Add Pagination -->
			<div class="swiper-pagination"></div>
			<!-- Add Arrows -->
			<div class="swiper-button-next"></div>
			<div class="swiper-button-prev"></div>
		</div>
		
	</div>
</div>
	
	
	</div>
	<div class="table_left">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2482.6390425280797!2d-0.12340508434246741!3d51.51983787963714!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48761b3425da86d3%3A0x743dbe2f638bce41!2s47%20Old%20Gloucester%20St%2C%20Holborn%2C%20London%20WC1N%203AD%2C%20UK!5e0!3m2!1sen!2sin!4v1574753874017!5m2!1sen!2sin" width="100%" height="400px" frameborder="0" style="border:0" allowfullscreen></iframe>

	</div>
	<div>
	
	
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/css/swiper.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/css/swiper.min.css">


	<?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.2/jquery.min.js"><?php echo '</script'; ?>
>

	<?php echo '<script'; ?>
 src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/js/swiper.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/js/swiper.min.js"><?php echo '</script'; ?>
>


	
	
	
		<?php echo '<script'; ?>
>
		
				var mySwiper = new Swiper ('#swiper1', {
					slidesPerView: 1,
					autoplay:true,
					pagination: {
						el: '.swiper-pagination',
						type: 'progressbar',
					  },
					  navigation: {
						nextEl: '.swiper-button-next',
						prevEl: '.swiper-button-prev',
					  },
				});
				
				
		<?php echo '</script'; ?>
>
		
		
				</div>
	
<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>