<?php /* Smarty version 3.1.27, created on 2019-11-27 20:26:38
         compiled from "/home/h27610/public_html/tmpl/account_main.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:17128346975ddedbfeac7648_62774036%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '576230fd9e1383c3b340ecb60dbdc490fb577782' => 
    array (
      0 => '/home/h27610/public_html/tmpl/account_main.tpl',
      1 => 1574754042,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17128346975ddedbfeac7648_62774036',
  'variables' => 
  array (
    'userinfo' => 0,
    'm' => 0,
    'settings' => 0,
    'last_access' => 0,
    'register_date' => 0,
    'currency_sign' => 0,
    'ab_formated' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5ddedbfeb734f4_35920105',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5ddedbfeb734f4_35920105')) {
function content_5ddedbfeb734f4_35920105 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/h27610/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '17128346975ddedbfeac7648_62774036';
echo $_smarty_tpl->getSubTemplate ("hustydesigns_framework/header_dash.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"> <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css" />
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"></head>
</div>
<h3 class="dbs1 container"><span>My</span> Dashboard</h3>

<?php if ($_smarty_tpl->tpl_vars['userinfo']->value['umessages']) {?>
<ul>
<?php
$_from = $_smarty_tpl->tpl_vars['userinfo']->value['umessages'];
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['m'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['m']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['m']->value) {
$_smarty_tpl->tpl_vars['m']->_loop = true;
$foreach_m_Sav = $_smarty_tpl->tpl_vars['m'];
?>
<li><?php echo smarty_modifier_myescape(nl2br(htmlspecialchars($_smarty_tpl->tpl_vars['m']->value['text'], ENT_QUOTES, 'UTF-8', true)));?>
</li>
<?php
$_smarty_tpl->tpl_vars['m'] = $foreach_m_Sav;
}
?>
</ul>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['settings']->value['use_transaction_code'] == 1 && $_smarty_tpl->tpl_vars['userinfo']->value['transaction_code'] == '') {?> <b>Note: currently you have not specified 
a Transaction code. The Transaction code strengthens your funds security in our 
system. The code is required to withdraw funds from your account<?php if ($_smarty_tpl->tpl_vars['settings']->value['internal_transfer_enabled']) {?> 
and for internal transfer to another user account<?php }?>. Just do not change 'Transaction 
code' in your account information if you do not want to use this feature. <a href=?a=edit_account>Click 
here</a> to specify a new transaction code .</b> <br>
<br>
<?php }?>



<style>


.hd-money i{
color:black;}

.dbs1 span{
	color:#15bc9b;
}
.dbs1{
font-family:Lato;
background-color:#fff;
border-radius:3px;
margin-top:30px;
line-height:65px;
font-size:28px;
color:#333 !important;
text-align:center;
border:1px solid #ddd;
font-weight:600;

margin-bottom:50px !important;

}
.hd-p{
font-family:poppins,sans-serif;
font-size:24px;
color:gray;
margin-top:15px;


}




.left-section {
width:700px;
display:inline-block;
margin-right:25px;
}
.userDetails {
text-align:center;
width:400px;border-top-left-radius: 0px !important;
margin-top:-20px !important;
height:580px;
padding-top:120px;

border:1px solid #ddd;
border-bottom:3px solid #ccc;
box-shadow: 0px 0px 5px 1px rgba(0, 0, 0, 0.1);
-moz-box-shadow: 0px 0px 5px 1px rgba(0, 0, 0, 0.1);
-webkit-box-shadow: 0px 0px 5px 1px rgba(0, 0, 0, 0.1);
color:white;
margin:40px 0 30px 0;
background-color:#17b897;
background-position:center center;
padding-left:30px !important;
padding-bottom:100px;
border-radius:3px !important;
}   


.leftpart
 {
width:49%;
display:block !important;
vertical-align:top;
text-align:left;
color:white;
}
.leftpart i {
box-shadow: 0px 2px 9px 0px rgba(119, 119, 119, 0.2);
-moz-box-shadow: 0px 2px 9px 0px rgba(119, 119, 119, 0.2);
-webkit-box-shadow: 0px 2px 9px 0px rgba(119, 119, 119, 0.2);
height:65px;
line-height:65px;
width:65px;
font-size:30px;
text-align:center;
color:white;
vertical-align:middle;
margin:20px 0px 20px 20px;
border-radius: 100px;
background-color:lightgray;
display:block;

}
.leftpart p {
padding-left:110px;
margin-top:0px;
margin-bottom:40px;
font-size:25px;
color:white;
text-shadow: 2px 2px 15px rgba(0,0,0,0.36);
font-weight:500;
}
.leftpart span {
padding-left:100px;
margin:-23px 0 33px 0;
display:block;
font-size:13px;
color:light  gray;
width:400px;


font-weight:400;
}
.logoutbtn {
box-shadow: 0px 2px 9px 0px rgba(119, 119, 119, 0.4);
-moz-box-shadow: 0px 2px 9px 0px rgba(119, 119, 119, 0.4);
-webkit-box-shadow: 0px 2px 9px 0px rgba(119, 119, 119, 0.4);
height:45px;
line-height:45px;
width:125px;
font-size:15px;
text-align:center;
color:#333 !important;
vertical-align:middle;
margin:30px 30px 0 0px;
border-radius: 3px;
display:inline-block;
background:#FECB1C;
}


.grbtn1{
display:block !important;
font-family:poppins,sans-serif;
font-size:18px;

}
.grbtn1 , .grbtn2 ,.grbtn2 a ,.grbtn1 a{
display:block !important;
font-family:poppins,sans-serif;
font-size:14px;

color:#17B897!important;
background-color:white!important;
width:340px;
border-radius:3px;
padding:8px 0px;
}
.grbtn1 , .grbtn2{
margin-top:10px;
border-bottom:2px solid white;
}

.grbtn1:hover, .grbtn2:hover{

border-bottom:2px solid gray;

}
.grbtn3 .logoutbtn{
font-family:poppins,sans-serif;
font-size:14px;
border-top:2px solid #078c71;
color:white !important;
background-color:#078c71;
}
.grbtn3 .logoutbtn:hover {
background-color:#17B897;
color:white!important;
border-top:2px solid white;}

#hd-money {
text-align:center;
position:absolute;
width:800px;
max-width:100%;

border-radius:10px;
color:#444;
margin:-640px 0 0 420px;
}
.earnedtotal{

border-radius:10px;
display:inline-block;
min-width:180px !important;
margin-left:-20px;


}

.hd-p{
color:#19b999;}

.hd-money .il{
font-size:44px;
color:#17B897;
}
.hd-money .hdtop{
font-family:Roboto,sans-serif;
font-size:14px;
color:#999;
margin:30px 0 0px 0;
}

.hd-money .hdtop1{font-family:roboto,sans-serif;
font-size:18px;
margin-top:5px;
margin-bottom:25px;
color:gray;
}
.hd-money .hdtop3{font-family:roboto,sans-serif;
font-size:14px;
color:gray;
font-weight:500;
border-radius:3px !important;}
.hd-money{
padding:20px;
}


.account{

min-width:180px;
display:inline-block;
float:left;
}


.deposit{

min-width:180px;}


.withtotal{

min-width:180px;

}


.hd-money{

}
#hd-money{


margin-left:430px;
border:2px solid white !important;
width:770px;

border-radius:9px;
margin-top:-610px;
padding-bottom:30px;
border-color:gray;
-webkit-box-shadow: px -1px 17px -11px rgba(0,0,0,0.3);
-moz-box-shadow: 1px -1px 17px -11px rgba(0,0,0,0.3);
box-shadow: 0px -1px 17px -11px rgba(0,0,0,0.3);

border-radius:3px !important;
}


.access{
margin-left:430px;
border:1px solid;
width:770px;
margin-bottom:100px;
padding:35px;
margin-top:-261px;
background-color:#19B999;
position:absolute;
border-color:gray;
border-top:none;-webkit-box-shadow: 1px -1px 17px -11px rgba(0,0,0,0.75);
-moz-box-shadow: 1px -1px 17px -11px rgba(0,0,0,0.75);
box-shadow: 1px -1px 17px -11px rgba(0,0,0,0.75);
border-radius:3px;
}
.buns{
display:inline-block;
padding:5px
0px;}
.qp{
font-family:poppins,sans-serif;
font-weight:600;
color:white;;
margin-top:0px !important;
}
.flexy{
display:flex;
margin-left:30px;}

.df{
color:#333;
border:2px solid white;
width:170px;
background:#fff !important;
line-height:45px !important;
padding:0 25px !important;
margin-top:10px;border-radius:3px !important;
}


.hd-money .hdtop3 {
background-color:#17B897 !important;
padding:10px 20px; 
border-radius:10px;
color:white;}

.hd-money .hdtop3:hover{
color:white ;
background-color:lightgray;}

.referrsection .ref1s{
font-family:raleway,sans-serif;
font-size:28px;
color:white;
position:absolute;
margin-left:160px;
margin-top:10px;

}


.blo{
display:block;
margin-top:-70px !important;
margin-left:135px !important;
position:absolute;;

}
.wl{
text-shadow:none !important;
font-family:roboto,sans-serif;
font-weight:300 !important;
}
.wl1{
margin-top:-40px !important;
width:225px;
text-shadow:none !important;}

.ll{
font-size:12px !important;
width:320px;
margin-left:-40px;
margin-top:0px !important;
text-shadow:none !important;}

.rd{
font-size:12px !important;
width:320px;text-shadow:none !important;
margin-top:-30px !important;
margin-left:-40px;}

.speedy{
color:white;
zoom:2;
margin: -10px auto !important;
width:350px;
}
.buns .btn {
width:140px;

margin-left:24px;}

.ref1s{
color:white !important;
width:500px;
margin-left:60px !important;
font-size:38px !important;
margin-top:-70px !important;}


.ref2s{
margin-left:-100px;
margin-top:60px;
margin-bottom:30px;

color:white!important;
}
.re_p{
margin-top:-300px;
margin-bottom:300px;
margin-left:500px;}
.referi{
height:361px;
border-radius:3px;
background-image:url("images/bg new.jpg");
background-size:cover;
background-repeat:no-repeat;
}
.ref4s{

position:absolute;
margin:70px 0px 20px -330px !important;
color:#fff;
border:1.5px solid white;
padding:10px 40px;
border-radius:100px;
 }

.ref4s img{
border:none;
width:30px !important;
margin-right:20px;}
.ref3s{
background-color:white;
padding:20px 50px ;
border-radius:3px;
margin:-120px 10px 40px 120px !important;

}


</style>

<div class="container brd">
<div class="left-section">
	<div class="userDetails">
		<div class="leftpart">
			<i class="fa fa-user blo"></i>
			<p class="text-center wl"> WELCOME </p>
			<p class="text-center wl1"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['username']);?>
</p>
			<p class="ll text-center"   > Last Login : <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['last_access']->value);?>
</p>
				<p class="rd text-center"> Register date: <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['register_date']->value);?>
</p>
		</div>
		<div class="rightpart"><div class="grbtn1">
			<a class="grbtn" href="./?a=edit_account"><i class="fa fa-gear"> </i>&nbsp;Edit profile</a></div>
			<div class="grbtn2">
			<a class="gebtn" href="./?a=security"><i class="fa fa-edit"> </i> &nbsp;Settings</a></div>
			<div class="grbtn3">
			<a class="logoutbtn" href="./?a=logout"><i class="fa fa-power-off"></i>&nbsp; Logout</a></div>
		</div>
	</div>
</div><div class="ohd-money">
	<div id="hd-money">	

		<p class="hd-p"> YOUR STATISTICS</p>
		<hr><div class="flexy">
		<div class="hd-money earnedtotal">
			<i class="icon-rocket il"></i>
			<span>
				<p class="hdtop">Earned Total</p>
				<h5 class="hdtop1"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['earning']);?>
</h5>	
			</span>
			<a href="./?a=deposit_history" class="hdtop3"> Deposit History</a>
		</div>
		<div class="hd-money withtotal">
			<i class="icon-wallet il"></i>
			<span>
			<p class="hdtop">Withdrew Total</p>
			<h5 class="hdtop1"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['withdrawal']);?>
</h5>	
			</span>
			<a href="./?a=withdraw_history" class="hdtop3"> Withdraw History</a>
		</div>
		<div class="hd-money account">
			<i class="icon-credit-card  il"></i>
			<span>
				<p class="hdtop">Account Balance</p>		
				<h5 class="hdtop1"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['total']);?>
</h5>
			</span>
			<a href="./?a=earnings" class="hdtop3"> Earnings History</a>
		</div>
		<div class="hd-money deposit">
			<i class="icon-notebook il"></i>
			<span>
				<p class="hdtop">Active Deposit</p>
				<h5 class="hdtop1"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['active_deposit']);?>
</h5>	
			</span>
			<a href="./?a=deposit_list" class="hdtop3"> My active Deposit</a>
		</div>	
	</div></div>

<div class="access">

<i class="material-icons speedy text-center">
speed
</i>
<p class="qp text-center"> QUICK ACCESS</p>
<hr style="border-color: white;">

<div class="buns">
<a class="btn df" href="./?a=deposit_history"> Deposit Funds</a>
<a class="btn df" href="./?a=withdraw_history"> Withdraw Funds</a>
<a class="btn df" href="./?a=edit_account"> Edit Profile</a>
<a class="btn df" href="./?a=earnings"> Earning History</a>


</div>




</div>




<div class="referi">
<div class="referrsection"><img src="images/refer.jpg"><div class="re_p">
	<h6 class="ref1s text-center">Refer Friends & earn more!</h6>	
	<p class="ref2s text-center">Your unique Referral Link</p>
	<span class="ref3s text-center">https://www.bitexbroker.com/?ref=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['username']);?>
</span>

	<a href="./?a=referallinks" class="ref4s" ><img src="images/tool.png" style="width:40px;">Promotional Tools</a>	
</div>		</div></div></div></div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>