<?php /* Smarty version 3.1.27, created on 2019-11-27 20:46:38
         compiled from "/home/h27610/public_html/tmpl/hustydesigns_framework/header_home.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:5283762125ddee0ae5285c7_68653588%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a9d2f5a460de528aee69bbd6dc3cca82bd55dcd7' => 
    array (
      0 => '/home/h27610/public_html/tmpl/hustydesigns_framework/header_home.tpl',
      1 => 1574877994,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5283762125ddee0ae5285c7_68653588',
  'variables' => 
  array (
    'settings' => 0,
    'userinfo' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5ddee0ae562626_24217627',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5ddee0ae562626_24217627')) {
function content_5ddee0ae562626_24217627 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/h27610/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '5283762125ddee0ae5285c7_68653588';
?>
<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	
	<title><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</title>
	<base href="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/" src="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--<meta name="viewport" content="width=device-width, initial-scale=1">-->
 <meta name="viewport" content="width=1400; user-scalable=1;" />
    <link rel="stylesheet" href="./template/plugins/animhead/css/style.css"> 
  <link href="images/logo.png" rel="icon" />
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="js/bootstrap.min.js"><?php echo '</script'; ?>
>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"><?php echo '</script'; ?>
>

<!-- fonts link in the tab--->
<link href="https://fonts.googleapis.com/css?family=Bai+Jamjuree&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Bai+Jamjuree&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
 <?php echo '<script'; ?>
 type="text/javascript" src="js/js.js"><?php echo '</script'; ?>
>
 <link rel="stylesheet" type="text/css" href="../css/style.css">
 

</head>
<style >
  .one_h{
display:inline-flex;
min-width:300px;

margin-top:50px;
}
      .invest{
margin-top:-60px;}
.navbar-toggler{

 margin-top:40px;
  margin-left:-200px;
}
.hd{
  margin-bottom: -10px;
}


.one_h li {
list-style-type:none;
padding:0px;
font-size:16px;
font-weight:400;
line-height:10px;
margin:0px;}
.o1l{
margin-top:-5px;
margin-left:20px;
margin-right:10px;}
.o2l{
margin-top:-10px;
margin-left:-5px;
margin-right:10px;
}
.o3l{
margin-top:-10px;
margin-right:10px;}

.dropdown1{
font-family:poppins,sans-serif;
font-size:18px ;
margin-top:44px;
margin-bottom:50px;}
.dropdown1 a{
font-size:12px;}
.pro{
margin-bottom:-120px;}
#navbarCollapse{
margin-top:-30px;
margin-left:170px;}
.container .pro_hr{
margin-top:-150px;
margin-bottom:60px;}
.navbar-toggler{
  margin-top:150px;
  margin-bottom:0px;
}
.nl1{
display:flex;
margin-top:-10px;
margin-left:-150px;}
.pro{
  margin-bottom: -20px;
}

@media only screen and (min-width: 320px) and (max-width: 1060px){
  .dropdown1{
    margin-top:60px;margin-left:250px;    
    position: relative  ;
    z-index: 99;
  }
.container hr{
display:none !important;}
.nl1{
display:block;
margin-top:-10px;
margin-left:20px;}

}



</style>
 <?php echo '<script'; ?>
 type="text/javascript" src="./template/assets/js/jquery.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="./template/assets/js/jquery.counterup.min.js"><?php echo '</script'; ?>
>
   
<link rel="stylesheet" href="./template/hd_animate.css">
<style>

/*
#particles-js{
  width: 100%;
  height: 835px;
position:absolute;
}*/
.cd-words-wrapper {
line-height:25px;
}
</style>



<!-- particles.js container -->
<div id="particles-js"></div>

<!-- //Partckes scripts -->
<?php echo '<script'; ?>
 src="./template/plugins/particles/particles.min.js"><?php echo '</script'; ?>
>
<!--<?php echo '<script'; ?>
 src="./template/plugins/particles/js/app.js"><?php echo '</script'; ?>
>--->

<body>
	  <header class="static-top">

    <div class="container hd">
      <div class="pro static-top">
  
        <!-- logo content--->
          <a href="#" class="navbar-brand ">
          <img src="images/logo.jpg" class="  dglogo text-center  float-center ">
          </a> <div class="top">
            <div class="container"> 
            <div class="row">
              <div class="col-lg-4 one_h leo">
            
                      <li><img  class ="o1l"src="images/t1.png"></li>
                      <li class=""><p class="n1h">47 Old Gloucester Street</p>
                        <p class="n1h">London, England, </p>
                          <p class="n1h">WC1N 3AD.   </p></li>
                      </div>

                      <div class="col-lg-4 one_h">
                      <li><img class ="o2l" class ="o1l"src="images/t2.png"></li>
                      <li><p class="n1h">contact@bitexbroker.com</p>
                        <p class="n1h">  Phone Available For Vip</p></li>
                    </div>

                      <div class="col-lg-4  one_h">
                      <li><img  class="o3l"  src="images/t3.png"></li>
                      <li class=""><p class="n1h">Number : 12319735</p>
                        <p class="n1h"><a style="color:#139780;" href="pdf/certificate.pdf" download>Download certificate</a></p></li>
               
                       </div>
                     </div>
                   </div>


                       <div class="dropdown1    ">


    <button class="btn  dropdown-toggle" type="button" data-toggle="dropdown"><span>English</span>
   </button><hr >
    <ul class="dropdown-menu">
      <li><a href="#">Tamil</a></li>
      <li><a href="#">German</a></li>
      <li><a href="#">French</a></li>
    </ul>
  </div>

</div> </div>  <hr class="pro_hr">

      
   <nav class="navbar navbar-expand-lg navbar-light bg-none static-top ">
          <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
          <i class="fa fa-bars" style="color:#15B596"></i>
          </button>
          <!-- navigation headings--->

          <div class="collapse navbar-collapse static-top" id="navbarCollapse">
          <div class="navbar-nav  d-flex    ">
            <a href="<?php echo smarty_modifier_myescape(encurl("?a=home"));?>
" class="  btn nav-item n1 nav-link ">HOME</a>
            <a href="<?php echo smarty_modifier_myescape(encurl("?a=cust&page=invest"));?>
" class="btn  n2 nav-item nav-link ">INVESTMENT</a>             
            <a href="<?php echo smarty_modifier_myescape(encurl("?a=cust&page=about"));?>
" class="btn nav-item  n3 nav-link ">ABOUT US</a>
             <a href="<?php echo smarty_modifier_myescape(encurl("?a=cust&page=security"));?>
" class="btn nav-item n3  nav-link ">SECURITY</a>
			             <a href="<?php echo smarty_modifier_myescape(encurl("?a=faq"));?>
" class=" btn nav-item n4 nav-link">FAQs</a>

            <a href="<?php echo smarty_modifier_myescape(encurl("?a=support"));?>
" class=" btn nav-item n4 nav-link">CONTACT US</a>
             <a href="representative.php" class=" btn nav-item n4 nav-link">REPRESENTATIVE</a>
  <?php if ($_smarty_tpl->tpl_vars['userinfo']->value['logged'] != 1) {?>
  <div class="nl1">
            <a href="<?php echo smarty_modifier_myescape(encurl("?a=login"));?>
" class= "btn nav-item r1 nav-link "> LOGIN</a>
                  <a href="<?php echo smarty_modifier_myescape(encurl("?a=signup"));?>
" class= "btn  r2 nav-item nav-link "> CREATE ACCOUNT  </a></div>
                        <?php } else { ?>
                        <div class="nl1">
                         <a href="<?php echo smarty_modifier_myescape(encurl("?a=logout"));?>
" class= "btn nav-item r1 nav-link "> LOGOUT</a>
                        <a href="<?php echo smarty_modifier_myescape(encurl("?a=account"));?>
" class= "btn  r2 nav-item nav-link ">DASHBOARD  </a>
</div>
<?php }?>


</div>
</div>
    <div class="clerfix"></div></div></nav></header>

<?php }
}
?>