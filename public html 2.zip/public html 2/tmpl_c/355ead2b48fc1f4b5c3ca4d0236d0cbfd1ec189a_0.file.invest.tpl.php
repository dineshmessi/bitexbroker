<?php /* Smarty version 3.1.27, created on 2019-11-27 20:33:59
         compiled from "/home/h27610/public_html/tmpl/custom/invest.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:16427679915ddeddb7cf8304_80445948%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '355ead2b48fc1f4b5c3ca4d0236d0cbfd1ec189a' => 
    array (
      0 => '/home/h27610/public_html/tmpl/custom/invest.tpl',
      1 => 1574881843,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16427679915ddeddb7cf8304_80445948',
  'variables' => 
  array (
    'userinfo' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5ddeddb7d908a6_94166076',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5ddeddb7d908a6_94166076')) {
function content_5ddeddb7d908a6_94166076 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/h27610/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '16427679915ddeddb7cf8304_80445948';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>




<style >
  @import url('https://fonts.googleapis.com/css?family=Poppins&display=swap');

.investy {
	padding: 0;
overflow:hidden;
}
.ip1 {
		margin: 30px 0 !important;
}
.prs {
	margin-left: 1px;
}

.sec-btn {
	margin-left: 25px !important;
	width: 150px;
	margin-top: 3px;
}

.form-control {
	margin-left: 25px !important;
}

.st1 .ol22 {
	display: inline-block !important;
	max-width: 400px !important;
}

.st1 .hd1 {
	width: 160px !important;
	display: inline-block !important;
	margin-right: 3px !important;
}

.tabys1 button {
	display: inline-block;
	width: 160px!important;
	margin: 0px 30px;
	padding: 10px 40px;
	background-color: #19BB9B;
	color: white;
	border: 2px solid white;
	border-radius: 3px;
	font-family: poppins, sans-serif;
	font-size: 24px;
}

button span {
	font-weight: 900;
	color: lightgray;
}

.tabys1 .active {
	background-color: white;
}

.tabys1 {
	background-color: #0E705D;
	padding: 30px;
}

.tab-answers {
	margin-top: 80px !important;
}

.lap1 {
	background-image: url("images/lap.png");
	background-size: contain;
	margin-left: 30px;
	background-repeat: no-repeat;
	max-width: 500px;
	max-height: 304px;
}

.side-con .amount1 {
	color: #19BB9B;
	font-family: poppins, sans-serif;
}

.side-con .amount2 {
	font-weight: 1000;
	margin-left: 10px;
	padding-top: 20px;
}

.side-con .amount4 {
	margin-left: 10px;
	font-size: 18px;
	margin-top: -10px;
}

.side-con .amount3 {
	margin-left: 10px;
	margin-top: -10px;
	padding-bottom: 20px;
}

.plan_title {
	font-family: poppins, sans-serif;
	margin-top: 20px;
	padding: 0px 40px;
	font-size: 50px;
}

.tab-answers {
	margin-top: 80px !important;
}

.plan_body {
	text-align: justify;
	padding: 0px 40px;
	font-family: poppins, sans-serif;
	font-size: 18px;
}

.pr1 {
	margin-bottom: -10px;
	margin-top: -12px;
}

.cal {
	margin-top: -60px;
	font-family: poppins, sans-serif;
	font-size: 18px;
	background-color: #19BB7C;
	padding: 30px 0px 10px 0px;
}

.sec-btn {
	border: none;
	padding: 7px 20px;
}

.sec-btn:hover {
	border: none;
	background-color: white;
	color: #19BB9B;
	font-weight: 500;
	padding: 7px 20px;
}

.cal select,
.cal input {
	padding: 20px 10px;
	font-size: 14px;
}

.cal select {
	padding: 0px 10px;
	height: 43px;
	color: gray;
}

@media screen and (max-width: 900px) and (min-width: 300px) {
	.prr {
		margin-top: 20px;
		margin-bottom: 20px;
	}
	.plan_title {
		font-family: poppins, sans-serif;
		margin-top: -80px;
		padding: 0px 40px;
		font-size: 50px;
	}
	.plan_body {
		margin-bottom: 70px;
	}
	
}

.pr2 {
font-size:30px !important;
background:none;
color:#fff;
padding:5px 0 !important;
text-align:center;
width:170px !Important;
border:0px solid #dedede !important;
}.btny{
display:block;
color:white !important;
font-size:14px !important;

background-color:lightgray !Important; 
padding:20px 10px!important;
line-height:40px !important; 
vertical-align:middle !important;
</style>

<?php echo '<script'; ?>
>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
<?php echo '</script'; ?>
>

<body>

  <div class="container-fluid">
    <div class="container invest text-center investy ">
       <p class="ip1"> Our <span> Investment </span> Plans </p>
  
      <div class=" tabys1" style="background-color:#19BB7C; ;">
        <button class="faq_main_title tablinks active" onclick="openCity(event, 'plan_a')">Plan<span > A</span> </button>
        <button class="faq_main_title tablinks" onclick="openCity(event, 'plan_b')">Plan <span >B</span></button>
        <button class="faq_main_title tablinks" onclick="openCity(event, 'plan_c')">Plan<span > C</span></button>
        <button class="faq_main_title tablinks" onclick="openCity(event, 'plan_d')">Plan
        <span > D</span></button>
      </div>

            <!--plan A-->
      <div class="tab-answers">
    <div id="plan_a" class="faq_block tabcontent activecontent">
      <div class="plan-con">
        <div class="row"> <div class="col-lg-5">
<div class="  lap1">
  <div class="side-con">
    <p class="amount1 amount2" ><span style="font-size: 55px;font-weight:bolder;
    ">13</span><span style="color: grey ; font-size:18px" >%</span></p>
    <p class="amount1 amount4" style="color: grey; font-weight:500;">Daily <span style="color: grey; font-weight:500;">For</span></p>
    <p class="amount1 amount3"><span style="font-weight: 700;font-size: 55px;">9</span> <span style="color:grey; font-size:18px;font-weight:500;">Days</span></p>
  </div></div>
</div>
      <!--laptop side plan content-->
<div class="col-lg-7">
  <div class="plan_title" style="color: #17B897">Plan A
</div><div class="plan_body">
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
</div>
</div>
</div>
</div>
</div>
          <!--plan B-->
<div id="plan_b" style="display:none" class="faq_block tabcontent">
      <div class="plan-con">
        <div class="row"> <div class="col-lg-5">
<div class="  lap1">
  <div class="side-con">
    <p class="amount1 amount2" ><span style="font-size: 55px;font-weight:bolder;
    ">160</span><span style="color: grey">%</span></p>
    <p class="amount1 amount4" style="color: grey; font-weight:500;">After</p>
    <p class="amount1 amount3"><span style="font-weight: 700;font-size: 55px;">7</span> <span style="color:grey; font-weight:500;">Days</span></p>
  </div></div>
</div>
      <!--laptop side plan content-->
<div class="col-lg-7">
  <div class="plan_title" style="color: #17B897">Plan B
</div><div class="plan_body">
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
</div>
</div>
</div>
</div>
</div>
          <!--plan C-->

<div id="plan_c" style="display:none" class="faq_block tabcontent">
      <div class="plan-con">
        <div class="row"> <div class="col-lg-5">
<div class="  lap1">
  <div class="side-con">
    <p class="amount1 amount2" ><span style="font-size: 55px;font-weight:bolder;
    ">250</span><span style="color: grey">%</span></p>
    <p class="amount1 amount4" style="color: grey; font-weight:500;">After</p>
    <p class="amount1 amount3"><span style="font-weight: 700;font-size: 55px;">5</span> <span style="color:grey; font-weight:500;">Days</span></p>
  </div></div>
</div>
      <!--laptop side plan content-->
<div class="col-lg-7">
  <div class="plan_title" style="color: #17B897">Plan C
</div><div class="plan_body">
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
</div>
</div>
</div>
</div>
</div>
            <!--plan D-->

<div id="plan_d" style="display:none"class="faq_block tabcontent">
      <div class="plan-con">
        <div class="row"> <div class="col-lg-5">
<div class="  lap1">
  <div class="side-con">
    <p class="amount1 amount2" ><span style="font-size: 55px;font-weight:bolder;
    ">450</span><span style="color: grey">%</span></p>
    <p class="amount1 amount4" style="color: grey; font-weight:500;">After</p>
    <p class="amount1 amount3"><span style="font-weight: 700;font-size: 55px;">3</span> <span style="color:grey; font-weight:500;">Days</span></p>
  </div></div>
</div>
      <!--laptop side plan content-->
<div class="col-lg-7">
  <div class="plan_title" style="color: #17B897">Plan D
</div><div class="plan_body">
Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
</div>
</div>
</div>
</div>
</div>


  </div>
 
 
 
	<?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.2/jquery.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="calc/js/html5.js" type="text/javascript"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="calc/js/scripts.js" type="text/javascript"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="calc/js/jquery-ui.js" type="text/javascript"><?php echo '</script'; ?>
>
	<link rel="stylesheet" href="calc/css/calc.css" type="text/css" />
	
	
  <div class="container">
  <form>
    <div class="row cal">
      <div class="col-lg-4">

  <div class="form-group prs text-center">
    <select class="calculate-select">
			<option value="1">13% daily for 9 days - 117% total ROI</option>
					<option value="2">160% after 7 days</option>
					<option value="3">250% after 5 days</option>
					<option value="4">450% after 3 days</option>
	</select>

</div>
</div>
<div class="col-lg-4 text-center">
  
    <input type="text" class="form-control pss calculate-amount" id="exampleFormControlInput1" placeholder="Enter Amount .$" >
</div>
<?php if ($_smarty_tpl->tpl_vars['userinfo']->value['logged'] != 1) {?>
 <div class="col-lg-2 prr text-center">
      <a class="sec-btn btn btny"  href="<?php echo smarty_modifier_myescape(encurl("?a=signup"));?>
" >Invest Now</a>
  </div>
   <?php } else { ?>
   <div class="col-lg-2 prr text-center">
       <div class="col-lg-2 prr text-center">
      <a class="sec-btn btn btny"  href="<?php echo smarty_modifier_myescape(encurl("?a=deposit"));?>
" >Invest Now</a>
  </div>
  </div>
  
  <?php }?>
  <div class="col-lg-2 prry text-center">
  <div class="amount">
  <p class="pr1" style="color:white;"><small>profit</small></p>
  <input class="pr2 total" value="$5.17"/>
  
</div>
</div></div></div>
</form>
</div>
</div>
</body>

</html>
<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<?php }
}
?>