<?php /* Smarty version 3.1.27, created on 2019-11-27 20:46:38
         compiled from "/home/h27610/public_html/tmpl/footer.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:353338425ddee0ae5b28f1_17055403%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9c1ee357098fcbbfef0c0c292e6bfe57625dc075' => 
    array (
      0 => '/home/h27610/public_html/tmpl/footer.tpl',
      1 => 1574753699,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '353338425ddee0ae5b28f1_17055403',
  'variables' => 
  array (
    'home' => 0,
    'homea' => 0,
    'ref' => 0,
    'userinfo' => 0,
    'membersidebar' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5ddee0ae5dd121_28967301',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5ddee0ae5dd121_28967301')) {
function content_5ddee0ae5dd121_28967301 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '353338425ddee0ae5b28f1_17055403';
if ($_SERVER['REQUEST_URI'] == $_smarty_tpl->tpl_vars['home']->value || $_SERVER['REQUEST_URI'] == $_smarty_tpl->tpl_vars['homea']->value || $_SERVER['REQUEST_URI'] == $_smarty_tpl->tpl_vars['ref']->value) {?>

	<?php echo $_smarty_tpl->getSubTemplate ("hustydesigns_framework/footer_home.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>
     

<?php } else { ?>
	
	<?php if ($_smarty_tpl->tpl_vars['userinfo']->value['logged'] == 1 && $_smarty_tpl->tpl_vars['membersidebar']->value != "yes") {?>
		
		<?php if ($_SERVER['REQUEST_URI'] == "/?a=support" || $_SERVER['REQUEST_URI'] == "/?a=faq" || $_SERVER['REQUEST_URI'] == "/?a=cust&page=invest" || $_SERVER['REQUEST_URI'] == "/?a=cust&page=affiliates" || $_SERVER['REQUEST_URI'] == "/?a=cust&page=about" || $_SERVER['REQUEST_URI'] == "/?a=cust&page=representatives" || $_SERVER['REQUEST_URI'] == "/?a=start" || $_SERVER['REQUEST_URI'] == "/?a=cust&page=bounty") {?>
			
			<!-- Show loggedin inner pages specific header -->
			<?php echo $_smarty_tpl->getSubTemplate ("hustydesigns_framework/footer_inners.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>
 
			
		<?php } else { ?>
			
			<!-- Dashboard Header -->
			<?php echo $_smarty_tpl->getSubTemplate ("hustydesigns_framework/footer_dash.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>
 
		
		<?php }?>
		
	<?php } else { ?>
	
		<!-- Not logged in inner pages Header -->
		<?php echo $_smarty_tpl->getSubTemplate ("hustydesigns_framework/footer_inners.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>
 
	
	<?php }?>

<?php }?>

	<?php }
}
?>