<?php /* Smarty version 3.1.27, created on 2019-11-27 20:33:59
         compiled from "/home/h27610/public_html/tmpl/hustydesigns_framework/footer_inners.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:21396799275ddeddb7e82fd5_01149483%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b2f195fbb0ced15cb0aeb168dc9f825c7badecca' => 
    array (
      0 => '/home/h27610/public_html/tmpl/hustydesigns_framework/footer_inners.tpl',
      1 => 1574879488,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21396799275ddeddb7e82fd5_01149483',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5ddeddb7e9f875_20892981',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5ddeddb7e9f875_20892981')) {
function content_5ddeddb7e9f875_20892981 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/h27610/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '21396799275ddeddb7e82fd5_01149483';
?>
</div>

<footer>
  <div class="foot">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="f1_cont">
            <p class="fp1">BITEX <span> BROKER</span></p><div class="a1">
            <a href="#" class="fa1">www.bitexbroker.com</a></div>
            <p class="fp2">Bitex Broker Limited is an investment advisor registered with the Securities and Exchange Commission ("SEC"). Any reference to the advisory services refers to Bitex Broker Limited. Registration does not imply a certain level of skill or training nor does it imply endorsement by the SEC.​ Past performance is not a guarantee of future return, nor is it necessarily indicative of future performance. Keep in mind investing involves risk.</p>
            <div class="flb"><ul>
             <li> <img src="images/logo.png"></li>
                <li><img src="images/fp3.png"></li>
                <li><img src="images/fp4.png"></li>
                <li><img src="images/fp5.png"></li>
                <li><img src="images/h1.png"></li>
                <li><img src="images/h2.png"></li>
                <li><img src="images/fp6.png"></li>
                </div></ul></div></div></ul>


                <!-- second column  of the footer  page --->
                <div class="col-lg-6 ">
                  <div class="f2_cont footer  fbr">
                    <div class="sy">

                    <p class="fpl2">WAYS TO REACH US</p>
                    <p class="fpl3">CONTACT <span>DETAILS</span></p></div>
                    <div class="fad fady12  ">
                      <li><img src="images/t1.png"></li>
                      <li class="float-left"><p class="fpad">47 Old Gloucester Street,</p>
                        <p class="fpad">London, England,</p>
                        <p class="fpad"> WC1N 3AD.</p></li>
                      </div>
                       <div class="fad " id="fad">
                      <li><img src="images/t2.png"></li>
                      <li class="float-left"><p class="fpad">contact@bitexbroker.com</p>
                        <p class="fpad">Phone Available For Vip</p></li>
                      </div>
                      <p class="cop"> Copyright ©2019 Bitex Broker Limited. All Rights Reserved.</p>
                      <ul>
                        <li><a href="#">Home</a></li>
 <li><a href="<?php echo smarty_modifier_myescape(encurl("?a=cust&page=about"));?>
" >About us</a></li>
 <li><a href="<?php echo smarty_modifier_myescape(encurl("?a=cust&page=invest"));?>
">Investment plans</a></li>

 <li><a href="<?php echo smarty_modifier_myescape(encurl("?a=rules"));?>
">Terms</a></li>
 <li><a href="<?php echo smarty_modifier_myescape(encurl("?a=faq"));?>
">F.A.Q</a></li>
 <li><a href="<?php echo smarty_modifier_myescape(encurl("?a=support"));?>
">Contact Us</a></li>
</ul></div>


                    </div></div></div></div></div></footer>

  <?php }
}
?>