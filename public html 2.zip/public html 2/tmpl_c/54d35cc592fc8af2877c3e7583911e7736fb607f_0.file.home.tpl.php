<?php /* Smarty version 3.1.27, created on 2019-11-27 20:46:38
         compiled from "/home/h27610/public_html/tmpl/home.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:21370186585ddee0ae4598e4_77257435%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '54d35cc592fc8af2877c3e7583911e7736fb607f' => 
    array (
      0 => '/home/h27610/public_html/tmpl/home.tpl',
      1 => 1574885354,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21370186585ddee0ae4598e4_77257435',
  'variables' => 
  array (
    'referer' => 0,
    'home' => 0,
    'ref' => 0,
    'homea' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5ddee0ae4de139_21839449',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5ddee0ae4de139_21839449')) {
function content_5ddee0ae4de139_21839449 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/h27610/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '21370186585ddee0ae4598e4_77257435';
$_smarty_tpl->tpl_vars['ref'] = new Smarty_Variable("/?ref=".((string)$_smarty_tpl->tpl_vars['referer']->value['username']), null, 0);?>
<?php $_smarty_tpl->tpl_vars['home'] = new Smarty_Variable("/", null, 0);?>
<?php $_smarty_tpl->tpl_vars['homea'] = new Smarty_Variable("/?a=home", null, 0);?>
<?php $_smarty_tpl->tpl_vars['logout'] = new Smarty_Variable("/?a=logout", null, 0);?>
<?php if ($_SERVER['REQUEST_URI'] == $_smarty_tpl->tpl_vars['home']->value || $_SERVER['REQUEST_URI'] == $_smarty_tpl->tpl_vars['ref']->value || $_SERVER['REQUEST_URI'] == $_smarty_tpl->tpl_vars['homea']->value) {?>
<?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

     
     <Style>
         .cd-words-wrapper {
padding:5px 0 !important;
}
footer{
  margin-top:-100px !important;
}
     </Style>
     
   
 
<!-- animated headline .js container -->
<!-- Resource style -->
  


<!-- <div class="block-img"> -->
		<!-- <img src="images/top.png" alt=""> -->
	<!-- </div> -->
		
					
</div>
<div class="header_content container-fluid">
    <div class="headings container wow fadeInUp">
         <div class="row text-center">
             
               <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 <p class=" he1 wow fadeInUp cd-headline push is-full-width text-center" data-wow-delay="0.5s">Don’t wait.</p>
          
          <p class="h1 wow fadeInUp cd-headline push is-full-width cd-words-wrapper">
          <b class="is-visible"> Open an <span>account today</span></b>
          <b>Start <span>to earn</span></b>
          <b>For <span>Luck</span></b>
          </p>
          </p> </div></div>
   <!-- <p class="h1 text-center">Don’t wait. Open an account today!</p> --->
    <p class="h2 text-center">It is a long established fact that a reader will be distracted by the
      readable content of a page when looking at its layout.</p>
      <div class="email_line">
     <form class=" buttons text-center" method="post" action="<?php echo smarty_modifier_myescape(encurl("?a=signup"));?>
">
    <input type="email" class="et float-center" name="email" placeholder="Email address"> <input type="submit" class="eb" value="Create account"></form>
    </div></div>
</div>

<!-- reading of censex like this --->
<div class="readings">
<marquee behavior="scroll" direction="left"><p class="sr1"> Walmart Inc (WMT)     <span style="color:green"> 89.17( 1.90%) </span></p>  <p class="sr1"> Walmart Inc (WMT)     <span style="color:red" > 89.17( 1.90%) </span></p> </marquee>
</div>
</div>
</div>
</div>

<!--- finishing of cenxes --->


<div class="knowledge container-fluid">
  <div class="knowledge_strength container">
    <p class="kp text-center"> Knowledge gives us strength </p> 
<div class="container kp1c">
  <div class="row">
    <div class="col-lg-4 col-md-12 b1"><div class="b2">
      <div class="pk1">
       <p class="k1">BEGINNERS COURSE</p> </div>
       <p class="k2"> Learn the basic concepts of trading, what this market is all about, and why you should be a part of it.</p> 
     </div>
         
       </div>
   
    <!-- second col-->
    <div class="col-lg-4  col-md-12 col-sm-12 col-xs-12 b1"><div class="b2">
       <div class="pk2">
       <p class="k1">TRADING TOOLS</p></div>
       <p class="k2"> Learn the basic concepts of trading, what this market is all about, and why you should be a part of it.</p> 
     </div>
    </div>
  <!-- third coliumn --->
    <div class="col-lg-4 col-xl-4  col-md-12 b1"><div class="b2">
       <div class="pk3">
       <p class="k1">TECHNICAL ANALYSIS</p></div>
       <p class="k2"> Learn the basic concepts of trading, what this market is all about, and why you should be a part of it.</p> 
     </div>
    </div></div>



    <div class="row kr2">
    <div class="col-lg-4 b1"><div class="b2">
       <div class="pk4">
       <p class="k1">FUNDAMENTAL ANALYSIS</p></div>
       <p class="k2"> Learn the basic concepts of trading, what this market is all about, and why you should be a part of it.</p> </div>
    </div>
    <!-- second col-->
  
  <!-- third coliumn --->

  <div class="col-lg-4 b1 "><div class="b2 ">
       <div class="pk5">
       <p class="k1">FUNDAMENTAL ANALYSIS</p></div>
       <p class="k2"> Learn the basic concepts of trading, what this market is all about, and why you should be a part of it.</p> 
     </div>
    </div>

 <div class="col-lg-4 b1 "><div class="b2  redy">
       <div class="pk6 red">
       <p class="k1 " > YOUTUBE TUTORIAL</p></div>
       <a href="https://www.youtube.com/watch?v=RDj8Y2K0ODA&t=26s" target="blank"  class="k2 redy1 "> Learn the basic concepts of trading, what this market is all about, and why you should be a part of it.</a> 
     </div>
    </div>
  </div></div></div></div></div>
     <!--  <p class="k2"> Learn the basic concepts of trading, what this market is all about, and why you should be a part of it.</p> --->
  

   <!--- the knowledge of six tab content are finished here  --->


   <div class="invest container">
    <div class="invest_plans container text-center">
      <p class="ip1"> Our <span> Investment </span> Plans </p>
    </div>
    <div class="container">

      <div class="row">
        <div class="col-lg-5 col-md-12">
          <div class="lb">

            <a class="btn" onclick="changeplan('1')">
          <div class="plans text-center"><p class="pp"> plan</p>
          <p class="pp1">A</p>
          </div> </a>

          <a  class="btn" onclick="changeplan('2')">
          <div class="plans text-center"><p class="pp"> plan</p>
          <p class="pp1">B</p>
          </div> 
        </a>


        <a class="btn"  onclick="changeplan('3')">
          <div class="plans text-center"><p class="pp"> plan</p>
          <p class="pp1">C</p>
          </div> 
        </a>


        <a class="btn" onclick="changeplan('4')">
          <div class="plans text-center"><p class="pp"> plan</p>
          <p class="pp1">D</p>
          </div>
          </a>



        </div>
        
        

	<?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.2/jquery.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="calc/js/html5.js" type="text/javascript"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="calc/js/scripts.js" type="text/javascript"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="calc/js/jquery-ui.js" type="text/javascript"><?php echo '</script'; ?>
>
	<link rel="stylesheet" href="calc/css/calc.css" type="text/css" />
	
	
	
          <!-- big black box --->
          <div class="bbox" id="log" >
            <div class="mm">
           <p class="bp1">Minimum</p>
           <p class="bp2">$<c id="p_min">30</c></p>
         </div> 
          <div class="mm">
            <p class="bp1">Maximum</p>
           <p class="bp2">$<c id="p_max">499</c></p>
           </div>
            <div class="mm">
            <p class="bp1">Principle Amount</p>
           <p class="bp2">included</p>
           </div>

          <div class="mm">
            <p class="bp1">Refrrral commission</p>
           <p class="bp2">5%-2%-1%</p>
           </div>


        </div>


<Style>
    .total {
width:190px !important;
padding:0 !important;
margin:0px !important;
height:65px;
font-size:45px;
border:none;
background:none!important ;
font-family:'Poppins', sans-serif !important;
}

.fa-chevron-up {
position:fixed;
right:30px;
color:#19BB9B !important;
bottom:20px;
z-index:10000;
font-size:30px !important;
background:rgba(0,0,0,0.1);
padding:20px 15px;
border-radius:5px;
}
</Style>


      </div>
      <!-- one column finishes here --->
      <div class="col-lg-7  col-md-12 lape">
   <!--first tab --->

        <div class="lap1" id="cal">
        <div class="off">
          <p class="of1"><c id="p_perc">13</c> <span>%</span></p>
          <p class="of2" id="p_dora"> Daily for</p>
          <p class="of3"><c id="p_days">9</c><span>Days</span></p>
        </div>
        <form class="lap">
        <div class="input">
            <input type="hidden"  class="calculate-select">
          <input type="text" name="amount" class="calculate-amount" placeholder="Enter amount"> </div>
          <div class="invest_button"> <input type="submit" value="INVEST NOW"></div></form>
          <div class="output">
            <p class="op1"> profit</p>
            <p class="op2"><sup>Total profit</sup></p>
              <p class="op2">  <input class="readonly total"  type="text" value="$6.30" readonly/></p>
              </div>
          </div>


        </div>
      </div>
      <hr>
    </div>
  </div>
  <!-- the laptop of plan investment content ends --->


  <div class=" statistics">
    <div class="statistics_content">
      <div class="container">
        <div class="row"> <div class="col-lg-4 st1 text-center"> <div class="st_c1  text-center">
            <p class="stp">  Live <b>statistics</b></p>
  <?php echo $_smarty_tpl->getSubTemplate ("info_box.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

</div></div>  
        <!-- first row ends --->


        <!-- second row starts--->
        <div class="col-lg-4 st1 text-center">
            <div class="st_c1 ol ">
            <p class="stp">  Recent <b>Deposits</b></p>
            <div class="ol22">
              <?php echo $_smarty_tpl->getSubTemplate ("index_last_deposits.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

            </div>
          </div>
        </div>



       
        <!--second row ends --->

        <!-- third row starts--->
        <div class="col-lg-4 st1 text-center">
            <div class="st_c1 ol ol1">
            <p class="stp">  Recent <b>Withdrawals</b></p> <div class="ol22">
              <?php echo $_smarty_tpl->getSubTemplate ("index_last_withdrawals.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

            </div>
          </div>
        </div>
      </div>
    </div></div></div>
           
          <!-- second row starts --->


      <!-- low regular partner --->

      <div class="lpa">
        <div class="container mission-background">
          <div class="row">
            <div class="col-lg-6 bglw">
              <div class="lpa_content">
                <p class="lp1">Low-Commission affiliates</p>
                <p class="lp2">REGULAR <span> PARTNER</span></p>
                <P class="lp3">This is our standard affiliate program. Every new member automatically becomes a rehular partner. There are 3 commission levels.</P>
                <div class="gt1">
                <div class="tab">
                  <div class="tab1">
                    <p class="tp1 text-right">commission</p>
                    <p class="tp2 text-right"> levels</p></div>
                    <img class="ti"src="images/g1.png">
                  </div>
                  <div class="table">
                  <table class="table  ">
  <thead>
    <tr>
     <th class="text-center th1">LEVEL 1</th>
      <th  class="text-center th1">LEVEL 2</th>
      <th class="text-center th1" >LEVEL 3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td  class="text-center tr1">6%</td>
      <td class="text-center tr1">2%</td>
      <td class="text-center tr1">1%</td>
    </tr>
   
  </tbody>
</table>
</div></div><a href="#"     
 class="re1"><div class="bg1">
 Register now to become a partner ! <i class="fa fa-arrow-right" style="color:gray" aria-hidden="true"></i></div></a>
        </div>

        <!-- second graph content --->
        
              <div class="lpa_content">
                <p class="lp1">High-Commission affiliates</p>
                <p class="lp2">GLOBAL <span> REPRESENTATIVE</span></p>
                <P class="lp3">This is our standard affiliate program. Every new member automatically becomes a rehular partner. There are 3 commission levels.</P>
                <div class="gt1">
                <div class="tab">
                  <div class="tab1">
                    <p class="tp1 text-right">commission</p>
                    <p class="tp2 text-right"> levels</p></div>
                    <img class="ti"src="images/g1.png">
                  </div>
                  <div class="table">
                  <table class="table  ">
  <thead>
    <tr>
     <th class="text-center th1">LEVEL 1</th>
      <th  class="text-center th1">LEVEL 2</th>
      <th class="text-center th1" >LEVEL 3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td  class="text-center tr1">8%</td>
      <td class="text-center tr1">3%</td>
      <td class="text-center tr1">1%</td>
    </tr>
   
  </tbody>
</table>
</div></div><a href="#"     
 class="re1"> <div class="bg1">
Register now to become a partner !<i class="fa fa-arrow-right" style="color:gray" aria-hidden="true"></i></div></a> 
        </div></div>


      
         <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 missions-right wow fadeInUp" data-wow-delay="1.2s">
             <div class="rot">
                <!--<h6>ICO & Crypto Currency Trading</h6>-->
                  <div class="progress">
                     
                     <div class="progress-bar1 progress-bar-primary" data-appear-progress-animation="65%"
                        data-appear-animation-delay="500"><p class="progress-bar-tooltip pt0">6%</p>
                        <!--<span>HTML/CSS</span>-->
                     </div>
                  </div>
                  <!--<h6>ICO & Crypto Currency Trading</h6>-->
                  <div class="progress">
                     <div class="progress-bar2 progress-bar-primary" data-appear-progress-animation="40%"
                        data-appear-animation-delay="500">
                        <!--<span>HTML/CSS</span>--> <p class="progress-bar-tooltip pt01">3%</p>
                     </div>
                  </div>
                <!-- <h6>Forex Trading</h6> --->
                  <div class="progress">
                     <div class="progress-bar1 progress-bar-primary" data-appear-progress-animation="15%"
                        data-appear-animation-delay="500">
                        <!--<span>HTML/CSS</span>--> <span class="progress-bar-tooltip pt02">1%</span>
                     </div>
                  </div>
               
                 
                 <!-- <h6>Real Estate Buisness</h6>--->
                  <div class="progress">
                     <div class="progress-bar1 progress-bar-primary" data-appear-progress-animation="80%"
                        data-appear-animation-delay="500">
                        <!--<span>HTML/CSS</span>--> <span class="progress-bar-tooltip pt1">8%</span>
                     </div>
                  </div>
                  
                  <div class="progress">
                     <div class="progress-bar2 progress-bar-primary" data-appear-progress-animation="40%"
                        data-appear-animation-delay="500">
                        <!--<span>HTML/CSS</span>--> <span class="progress-bar-tooltip pt2">3%</span>
                     </div>
                  </div>  
                  
                  <div class="progress">
                     <div class="progress-bar1 progress-bar-primary" data-appear-progress-animation="15%"
                        data-appear-animation-delay="500">
                        <!--<span>HTML/CSS</span>--> <span class="progress-bar-tooltip pt3">1%</span>
                     </div>
                  </div>
                  
                  
                  </div>
                  <div class="rot2">
                      <p class="rtp1"> Regular partner</p><p class="rtp2">Global Representative</p>
                  </div>
                   <a href="representative.php"     
 class="re1"><div class="bg2">
 VIEW OUR GLOBAL REPRESENTATIVES  <i class="fa fa-arrow-right" style="color:white" aria-hidden="true"></i></div></a>
               </div>
       
       
</div></div></div></div></div>

 <?php echo '<script'; ?>
 src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"><?php echo '</script'; ?>
>
 <?php echo '<script'; ?>
 src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"><?php echo '</script'; ?>
>

 

   
  
<?php echo '<script'; ?>
 type="text/javascript" src="./template/assets/js/bootstrap.min.js"><?php echo '</script'; ?>
> <!-- bootstrap js -->
<?php echo '<script'; ?>
 type="text/javascript" src="./template/assets/js/smoothscroll.min.js"><?php echo '</script'; ?>
> <!-- for smooth scroling -->

  <?php echo '<script'; ?>
 type="text/javascript" src="./template/assets/js/plugins.js"><?php echo '</script'; ?>
> <!--  progress bar -->
      <?php echo '<script'; ?>
 type="text/javascript" src="./template/assets/js/theme.js"><?php echo '</script'; ?>
><!--  progress bar -->
      <?php echo '<script'; ?>
 type="text/javascript" src="./template/assets/js/theme.init.js"><?php echo '</script'; ?>
><!--  progress bar -->
      <?php echo '<script'; ?>
 src="./template/assets/js/jquery-piecharts.js"><?php echo '</script'; ?>
>   <!-- progress bar -->
    
     
      <?php echo '<script'; ?>
 src="./template/assets/owl-carousel/owl.carousel.min.js"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 src="./template/plugins/animhead/js/main.js"><?php echo '</script'; ?>
> <!-- Resource jQuery -->

<?php echo '<script'; ?>
 src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"><?php echo '</script'; ?>
>


<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

	<?php } else { ?>
<center style="font-family:poppins,sans-serif;">
<img src="template/910.gif" style="width:100px;margin-top:10%"/>
<h1 style="color:#19BA99;margin-left: 10px;"> redirecting.........</h1>
<META HTTP-EQUIV=Refresh CONTENT="3; URL=./">
<span>Hold on . Or <a href="./">Click here</a></span>
</center>
<?php }?>

<?php }
}
?>