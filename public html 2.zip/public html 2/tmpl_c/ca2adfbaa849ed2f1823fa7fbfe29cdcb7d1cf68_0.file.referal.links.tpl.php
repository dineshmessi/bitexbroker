<?php /* Smarty version 3.1.27, created on 2019-11-27 20:26:43
         compiled from "/home/h27610/public_html/tmpl/referal.links.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:9418553615ddedc032a9ca9_24306274%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ca2adfbaa849ed2f1823fa7fbfe29cdcb7d1cf68' => 
    array (
      0 => '/home/h27610/public_html/tmpl/referal.links.tpl',
      1 => 1574753639,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9418553615ddedc032a9ca9_24306274',
  'variables' => 
  array (
    'user' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5ddedc03347753_37083092',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5ddedc03347753_37083092')) {
function content_5ddedc03347753_37083092 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/h27610/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '9418553615ddedc032a9ca9_24306274';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<style>
.inpts{
height:auto !important;
min-height:0 !important;
overflow:hidden !important;
}
</style>

<h3>Promotional Tools</h3>
<a href="<?php echo smarty_modifier_myescape(encurl("?ref=".((string)$_smarty_tpl->tpl_vars['user']->value['username'])));?>
"><img src="./banners/banner-468.gif"/></a>
<br><br><textarea class=inpts cols=60 rows=1><a href="<?php echo smarty_modifier_myescape(encurl("https://www.bitexbroker.com/?ref=".((string)$_smarty_tpl->tpl_vars['user']->value['username'])));?>
"><img src="https://www.bitexbroker.com/banners/banner-468.gif"/></a>
</textarea><br><br><br>
<a href="<?php echo smarty_modifier_myescape(encurl("?ref=".((string)$_smarty_tpl->tpl_vars['user']->value['username'])));?>
"><img src="./banners/banner-728.gif"/></a>
<br><br><textarea class=inpts cols=60 rows=1><a href="<?php echo smarty_modifier_myescape(encurl("https://www.bitexbroker.com/?ref=".((string)$_smarty_tpl->tpl_vars['user']->value['username'])));?>
"><img src="https://www.bitexbroker.com/banners/banner-728.gif"/></a>
</textarea><br><br><br>
<!--
<a href="<?php echo smarty_modifier_myescape(encurl("?ref=".((string)$_smarty_tpl->tpl_vars['user']->value['username'])));?>
"><img src="./banners/125.gif"/></a>
<br><br><textarea class=inpts cols=60 rows=1><a href="<?php echo smarty_modifier_myescape(encurl("https://www.bitexbroker.com/?ref=".((string)$_smarty_tpl->tpl_vars['user']->value['username'])));?>
"><img src="https://www.bitexbroker.com/banners/125.gif"/></a>
</textarea><br><br><br>

<a href="<?php echo smarty_modifier_myescape(encurl("?ref=".((string)$_smarty_tpl->tpl_vars['user']->value['username'])));?>
"><img src="./banners/1920.gif"/></a>
<br><br><textarea class=inpts cols=60 rows=1><a href="<?php echo smarty_modifier_myescape(encurl("https://www.bitexbroker.com/?ref=".((string)$_smarty_tpl->tpl_vars['user']->value['username'])));?>
"><img src="https://www.bitexbroker.com/banners/1920.gif"/></a>
</textarea><br><br><br>
-->
<a href="<?php echo smarty_modifier_myescape(encurl("?ref=".((string)$_smarty_tpl->tpl_vars['user']->value['username'])));?>
"><img src="./banners/banner-125.gif"/></a>
<br><br><textarea class=inpts cols=60 rows=1><a href="<?php echo smarty_modifier_myescape(encurl("https://www.bitexbroker.com/?ref=".((string)$_smarty_tpl->tpl_vars['user']->value['username'])));?>
"><img src="https://www.bitexbroker.com/banners/banner-125.gif"/></a>
</textarea><br><br><br>
<a href="<?php echo smarty_modifier_myescape(encurl("?ref=".((string)$_smarty_tpl->tpl_vars['user']->value['username'])));?>
"><img src="./banners/banner-1200.gif"/></a>
<br><br><textarea class=inpts cols=60 rows=1><a href="<?php echo smarty_modifier_myescape(encurl("https://www.bitexbroker.com/?ref=".((string)$_smarty_tpl->tpl_vars['user']->value['username'])));?>
"><img src="https://www.bitexbroker.com/banners/banner-1200.gif"/></a>
</textarea><br><br><br>
<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>