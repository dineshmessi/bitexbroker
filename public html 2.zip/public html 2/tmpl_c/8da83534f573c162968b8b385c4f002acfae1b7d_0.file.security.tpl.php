<?php /* Smarty version 3.1.27, created on 2019-11-27 20:33:11
         compiled from "/home/h27610/public_html/tmpl/custom/security.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:4393640215ddedd877131a7_04054331%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8da83534f573c162968b8b385c4f002acfae1b7d' => 
    array (
      0 => '/home/h27610/public_html/tmpl/custom/security.tpl',
      1 => 1574753639,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4393640215ddedd877131a7_04054331',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5ddedd877834a0_04286307',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5ddedd877834a0_04286307')) {
function content_5ddedd877834a0_04286307 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '4393640215ddedd877131a7_04054331';
echo $_smarty_tpl->getSubTemplate ("hustydesigns_framework/header_home.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>




<style>

	.ws6 {font-size: 8px;}
.ws7 {font-size: 9.3px;}
.ws8 {font-size: 11px;}
.ws9 {font-size: 12px;}
.ws10 {font-size: 13px;}
.ws11 {font-size: 15px;}
.ws12 {font-size: 16px;}
.ws14 {font-size: 19px;}
.ws16 {font-size: 21px;}
.ws18 {font-size: 24px;}
.ws20 {font-size: 27px;}
.ws22 {font-size: 29px;}
.ws24 {font-size: 32px;}
.ws26 {font-size: 35px;}
.ws28 {font-size: 37px;}
.ws36 {font-size: 48px;}
.ws48 {font-size: 64px;}
.ws72 {font-size: 96px;}
.wpmd {font-size: 13px;font-family: Arial,Helvetica,Sans-Serif;font-style: normal;}
/*----------Para Styles----------*/
DIV,UL,OL /* Left */
{
 margin-top: 0px;
 margin-bottom: 0px;
}
</style>

<style type="text/css">
#container
{
	position:relative;
	width: 1200px;
	height: 1630px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {margin:0}
.hdp1{
float:center;
margin-left:90px;
margin-top:40px;}
}
.hdp2{
margin-top:200px !important;


justify-content: center;}
</style>

<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1200px; height:393px; z-index:0"><img src="images/hbd1.jpg" alt="" title="" border=0 width=1200 height=393></div>

<div id="text1" style="position:absolute; overflow:hidden; left:40px; top:80px; width:1016px; height:101px; z-index:1">
<div class="wpmd">
<div class="text-center   hdp1"><font color="#FFFFFF" face="Poppins SemiBold" class="ws36 text-center">We Here Protect Your Funds</font></div>
</div></div>

<div id="text2" style="position:absolute; overflow:hidden; left:40px; top:190px; width:1109px; height:168px; z-index:2">
<div class="wpmd">
<div class="hdp2 justify-content-center text-align-center"><font color="#FFFFFF" face="Poppins" class=" justify-content-center  text-align-center ws16">Here at HotForex we understand that successful traders have to give their full attention to their trading rather than worrying about the safety of their funds. We have therefore taken additional measures to ensure adequate levels of safety for your funds.</font></div>
</div></div>

<div id="text3" style="position:absolute; overflow:hidden; left:160px; top:534px; width:1040px; height:110px; z-index:3">
<div class="wpmd">
<div align=justify><font color="#333333" face="Poppins" class="ws14">The Company has made further efforts to safeguard its liabilities against Clients and other third parties with a Civil Liability insurance program for a limit of €5,000,000, which includes market leading coverage against errors, omissions, negligence, fraud and various other risks that may lead to financial loss.There is no additional cost to our clients for this cover.</font></div>
</div></div>

<div id="text4" style="position:absolute; overflow:hidden; left:160px; top:749px; width:1038px; height:101px; z-index:4">
<div class="wpmd">
<div align=justify><font color="#000000" face="Poppins" class="ws14">The HotForex brand has become a global leader in online trading, specializing in forex, derivatives on US and UK stocks, commodities, spot metals, and indices.Client fund security has been a part of our philosophy alongside unmatched trading conditions and customer support. </font></div>
</div></div>

<div id="text5" style="position:absolute; overflow:hidden; left:160px; top:951px; width:1039px; height:61px; z-index:5">
<div class="wpmd">
<div align=justify><font color="#000000" face="Poppins" class="ws14">HotForex made the decision to only use major global banks. The strength and international standing of the HotForex brand enables the company to provide liquidity through major banks.</font></div>
</div></div>

<div id="text6" style="position:absolute; overflow:hidden; left:159px; top:1141px; width:1040px; height:57px; z-index:6">
<div class="wpmd">
<div align=justify><font color="#000000" face="Poppins" class="ws14">Clients’ funds are received into bank accounts separate from those used by the company. These funds are off the balance sheet and cannot be used to pay back creditors in the unlikely event of the default of the Company.</font></div>
</div></div>

<div id="text7" style="position:absolute; overflow:hidden; left:159px; top:1320px; width:1041px; height:86px; z-index:7">
<div class="wpmd">
<div align=justify><font color="#000000" face="Poppins" class="ws14">Volatility often occurs in the market. HotForex’s policy of negative balance protection means that even under highly volatile conditions when margin calls and stopouts do not function correctly, no client is responsible for paying back a negative balance.</font></div>
</div></div>

<div id="text8" style="position:absolute; overflow:hidden; left:160px; top:1523px; width:1040px; height:126px; z-index:8">
<div class="wpmd">
<div align=justify><font color="#000000" face="Poppins" class="ws14">The Company continually identifies, assesses, and monitors each type of risk associated with its operations. This means assessing on a continuous basis the effectiveness of the policies, arrangements, and procedures in place which allow the company to easily be able to cover its financial needs and capital requirement at any time.</font></div>
</div></div>

<div id="text9" style="position:absolute; overflow:hidden; left:160px; top:494px; width:427px; height:43px; z-index:9">
<div class="wpmd">
<div><font color="#19BB9B" face="Poppins" class="ws18"><B>Market Leading Insurance</B></font></div>
</div></div>

<div id="text10" style="position:absolute; overflow:hidden; left:160px; top:709px; width:489px; height:42px; z-index:10">
<div class="wpmd">
<div><font color="#19BB9B" face="Poppins" class="ws18"><B>Industry leader leading financial safety</B></font></div>
</div></div>

<div id="text11" style="position:absolute; overflow:hidden; left:160px; top:911px; width:338px; height:31px; z-index:11">
<div class="wpmd">
<div><font color="#19BB9B" face="Poppins" class="ws18"><B>Accounts with major banks</B></font></div>
</div></div>

<div id="text12" style="position:absolute; overflow:hidden; left:159px; top:1097px; width:404px; height:35px; z-index:12">
<div class="wpmd">
<div><font color="#19BB9B" face="Poppins" class="ws18"><B>Segregation of funds</B></font></div>
</div></div>

<div id="text13" style="position:absolute; overflow:hidden; left:159px; top:1278px; width:429px; height:47px; z-index:13">
<div class="wpmd">
<div><font color="#19BB9B" face="Poppins" class="ws18"><B>Negative balance protection</B></font></div>
</div></div>

<div id="text14" style="position:absolute; overflow:hidden; left:160px; top:1486px; width:362px; height:26px; z-index:14">
<div class="wpmd">
<div><font color="#19BB9B" face="Poppins" class="ws18"><B>Risk management</B></font></div>
</div></div>

<div id="image2" style="position:absolute; overflow:hidden; left:7px; top:488px; width:140px; height:145px; z-index:15"><img src="images/5.png" alt="" title="" border=0 width=140 height=145></div>

<div id="image3" style="position:absolute; overflow:hidden; left:9px; top:1469px; width:123px; height:169px; z-index:16"><img src="images/6.png" alt="" title="" border=0 width=123 height=169></div>

<div id="image4" style="position:absolute; overflow:hidden; left:4px; top:1266px; width:137px; height:142px; z-index:17"><img src="images/money-bag.png" alt="" title="" border=0 width=137 height=142></div>

<div id="image5" style="position:absolute; overflow:hidden; left:13px; top:888px; width:122px; height:126px; z-index:18"><img src="images/bank icon.png" alt="" title="" border=0 width=122 height=126></div>

<div id="image6" style="position:absolute; overflow:hidden; left:9px; top:698px; width:124px; height:137px; z-index:19"><img src="images/globe.png" alt="" title="" border=0 width=124 height=137></div>

<div id="image7" style="position:absolute; overflow:hidden; left:13px; top:1067px; width:119px; height:141px; z-index:20"><img src="images/5633 [Converted].png" alt="" title="" border=0 width=119 height=141></div>

</div>

</body>



<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<?php }
}
?>