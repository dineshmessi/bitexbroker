<?php /* Smarty version 3.1.27, created on 2019-11-27 20:34:03
         compiled from "/home/h27610/public_html/tmpl/custom/about.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:8926238565ddeddbbcdfeb5_48432020%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6a1cc3841950a4bbcb1a49fb254782433872b0fc' => 
    array (
      0 => '/home/h27610/public_html/tmpl/custom/about.tpl',
      1 => 1574753639,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8926238565ddeddbbcdfeb5_48432020',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5ddeddbbd467d2_17149287',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5ddeddbbd467d2_17149287')) {
function content_5ddeddbbd467d2_17149287 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '8926238565ddeddbbcdfeb5_48432020';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

</div>


<style type="text/css">
/*----------Text Styles----------*/

/*----------Para Styles----------*/
body
{
margin:0;
padding:0;
font-family:Poppins,sans-serif!important;
font-size:15px;
color:#565656;
word-spacing:-0.5px;
height:auto !important;
background:#fff !important;
}
.imsai{

margin-top: 40px;height
}
button
{
border:none;
border-radius:3px;
width:200px;
height:40px;
font-family:poppins,sans-serif;
font-weight:bold;
font-size:16px;
margin-top:0px;
}
.move a
{
text-decoration:none;
color:#ffff;
font-weight:700;
}


/********************About us*****************/
.aboutus
{
width:500px;
margin-top:100px;
}

.aboutus h3
{
color:#1DBC9C;
font-size:35px;

}
.aboutus p
{
line-height:22px;
text-align:justify;
width:470px;
}

.btn1 ,.btn2
{
background-color:#1DBC9C;


}
.btn3 ,.btn4
{
background-color:#787878;

}
/********************video*****************/
.video
{
margin-left:60px !important;
display:block;
float:right;
}

iframe
{
height:470px;
width:600px;
border-radius:10px;
margin:-400px 0 0 -150px !important;
}

/********************Certificate*****************/

.second
{
margin-top:180px;
width:500px;
height:600px;
max-height:500px;
}
.second .certifiacte
{

width:200px;
margin-top:0px;


}
.incorporation1 p,.incorporation2 p
{
color:#0e705d;
font-size:24px;

}

.incorporation1 p span,.incorporation2 p span
{
color:#0e705d;
font-size:28px;
font-weight:700;
line-height:0.5
}

.incorporation2
{

margin-top:0px;

}

.incorporation1 img,.incorporation2 img
{
height:70px;
width:70px;
padding-left:10px;

}

#h
{

margin-top:200px;
}
.incorporation1
{
margin-top:40px;
}


/********************Line*****************/
.line_1,.line_2
{
height:300px;
width:0.5px;
margin-left:265px;
border:solid #C4C4C4 0.5px;

}

.line_1
{

margin-top:-500px;

margin-bottom:00px;
}
.line_2
{
margin-top:50px;
}
/********************Certificate_image*****************/
.certifiacte_img
{

width:200px;
height:400px;
margin-left:300px;
margin-top:0px;
}

.incorporation_img1 img,.incorporation_img2 img
{

height:300px;
width:180px;
background-color:gray;
opacity:0.2;
}

.incorporation_img1 {
margin-top:-260px;
}
.incorporation_img2{
margin-top:50px;
}

/********************company details*****************/

.right_content_1,.right_content_2
{
width:650px;
float:right;
text-align:justify;
color:#8E8E8E;

}

.right_content_1
{
margin:-1300px 0 0 820px !important;position: absolute;
}
.right_content_2
{
margin:-980 0 0 820px !important;
position: absolute;
}
.company_num
{
width:300px;
color:#8E8E8E;
display: inline;
}

.company_num .num , .company_name .name
{
color:#19bb9b;
font-weight:600;
font-size:24px;
margin-top:-10px;

}
.company_name
{
float:right;
margin-left:-500px;
width:300px;
margin-top:-95px;
}
.c_name
{
color:#777777;
font-size:16px;
margin-top:50px;
}


.group,.group_reg
{
position: absolute;
width: 478px;
height: 655px;
margin-left:500;
top: 44px;
background: #FFFFFF;
border: 1px solid #E5EDF3;
box-sizing: border-box;
box-shadow: 0px 6px 36px rgba(0, 62, 100, 0.0429688);
border-radius: 4px;
font-family: 'Poppins', sans-serif;
font-style: normal;
font-weight: normal;
font-size: 14px;
line-height: 21px;
}
.ab2{
margin-top:650px !important;
margin-left:-100px !important;
margin-bottom: 300px !important;
position: absolute;
}
.company_num{
margin-top:100px;
}
.imsa{
position:absolute;
margin-top:-400px !important;
margin-left:300px !important;
margin-bottom: 400px;}
.imsa1{
position:absolute;
margin-top:-100px !important;
margin-left:300px!important;}
.company_name{
margin-top:-120px!important;}
.aboutra{
margin-bottom:-40px !important;
padding-bottom: 100px;}

.right_content_2{
margin-top:-989px;
margin-left:820px;}



/**************image*************/

.losange, .losange div {
  margin: 0 auto;
  transform-origin: 50% 50%;
  overflow: hidden;
  width: 250px;
  height: 250px;
}
.losange {
  transform: rotate(45deg) translateY(10px);
}
.losange .los1 {
  width: 355px;
  height: 355px;
  transform: rotate(-45deg) translateY(-74px);
  border:2px solid black;
}
.losange .los1 img {
  width: 100%;
  height: auto;
}
.photo{
margin-left:30px;
width:1200px;}
.second{

margin-top:100px !important;}

.teamy{
margin-top:260px;}
.ab1_pt{
margin-top:-170px;
margin-left:360px;
position:absolute;
font-size:35px;
color:gray;
font-weight:500;
}
.ab1_pt span{
color:#17b897;
}

.losange {
border:4px solid #17b897;}
.col-lg-3{
}

.downy{
margin-top:100px;}

.texy{
font-family:poppins,sans-serif;
font-size:16px;
font-weight:600;}
.texy1{
color:#17b897;
font-family:poppins,sans-serif;
font-size:16px;
font-weight:600;}


.move{
margin-top:220px;}
.movy{
margin-top:30px;}

.ab2{
margin-top:-1000px !important;
position:absolute;}
.move{
margin-top:860px !important;
margin-left:-100px;}

.second{
background:none !important;}
.imsa{
opacity:1 !important;
}
.sp{
margin-top:-20px !important;
}
.ptf3{
	margin-left:-30px !important;
}
.second{
background:none !important;
margin-left:160px !important;}
.imsa{
opacity:1 !important;


}
.move{ 
margin-left:-150px !important;}

.aboutcertificates{
width:1400px;
height:700px;
margin:0 auto;
}
</style>


<body>
<div class="aboutra">
	<div class="container imsai">
<div class="container_inner">
<div class="aboutus">
<h3>About Us</h3>
<P>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
when an unknown printer took a galley of type and srcambled it to make a type specimen book.
It has survived not only five centuries, but also the leap into electronic typesetting,
remaining essentially unchanged. It was popularised in the 1960s with the release of
Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing
software like Aldus PageMaker including versions of Lorem Ipsum.</p>
<button class="btn1 myLinkToTop" id="but1">Read More</button>
</div>
<?php echo '<script'; ?>
 type="text/javascript">
 $('.myLinkToTop').click(function () {
    $('html, body').animate({
        scrollTop:'960px'
    }, 'slow');
    return false;
});


<?php echo '</script'; ?>
>
<div class="video">
<iframe width="100%" height="100%" src="https://www.youtube.com/embed/aqz-KE-bpKQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen ></iframe>
</div></P></div></div></div>
<div class="container-fluid teamy  container">
	<div class="row photo">
		<p class="ab1_pt text-center"> Our <span>Professional</span> Team</p>
		<div class="col-lg-3 ">
			 <div class="losange">
      <div class="los1">
        <img src="tmplimg/m1.jpg" alt="" width="255" height="320" />
      
      </div>
    </div>
  <p class="texy"> MAZE</p>
        <p class="texy1"> CEO OF BITEX</p> </div>


    <div class="col-lg-3 offset-1">
			 <div class="losange">
      <div class="los1">
        <img src="tmplimg/m2.jpg" class="low1" alt="" />
      </div>
    </div>
  <p class="texy"> MAZE</p>
        <p class="texy1"> CEO OF BITEX</p></div>


    <div class="col-lg-3 offset-1">
			 <div class="losange">
      <div class="los1">
        <img src="tmplimg/m3.jpg" class="low2" alt="" width="255" height="320" />
      </div>
    </div>
      <p class="texy"> MAZE</p>
        <p class="texy1"> CEO OF BITEX</p>
</div>
</div>

    <div class="row downy"><div class="offset-3"></div>
    	<div class="col-lg-3  float-right pft_2">

			 <div class="losange">
      <div class="los1">
        <img src="tmplimg/m4.jpg"   alt="" width="255" height="320" />
      </div>
    </div>
  <p class="texy wow fadeInRight"> MAZE</p>
        <p class="texy1 wow fadeInRight"> CEO OF BITEX</p></div>
        	<div class="col-lg-3 offset-2		 pft_3">

			 <div class="losange">
      <div class="los1">
        <img src="tmplimg/m5.jpg"  alt="" width="255" height="320" />
      </div>
    </div>
  <p class="texy wow wow fadeInRight"> MAZE</p>
        <p class="texy1 wow fadeInRight"> CEO OF BITEX</p></div>



</div></div></div>

<!-- office --->





<div class="aboutcertificates">


<div class="second container">
<div class="certifiacte">
<div class="incorporation1 " id="i">
<img src="images/cer1.png" alt="incorporation certificate"></img>
<p>Cerificate of<span> Incorporation</span></p>
</div>
<div class="incorporation2" id="h">
<img src="images/cer2.png" alt="incorporation certificate"></img>
<p>Cerificate of<span> Insurance</span></p>
</div>
</div>
<hr class="line_1">
<hr class="line_2">
<div class="incorporation_img1">
<img class="imsa"src="images/certi1.jpg" alt="incorporation certificate">
</div>
<div class="incorporation_img2">
<img src=""class="imsa1" alt="incorporation certificate">
</div></div>


<div class="move container">


<div class="right_content_1">
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
when an unknown printer took a galley of type and srcambled it to make a type specimen book.</p>
<div class="company_num">
<p class="c_name">Company number</p>
<p class="num">12319735</p>
</div>
<div class="company_name">
<p class="c_name">Company name</p>
<p class="name">BiteXBroker LTD</p>
</div>
<button class="btn2"><a href="https://beta.companieshouse.gov.uk/company/12319735">Verify certificate</a></button>
<button class="btn3"><a href="pdf/certificate.pdf" download>Download certificate</a></button>
</div>
<div class="movy">
<div class="right_content_2">
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
when an unknown printer took a galley of type and srcambled it to make a type specimen book.</p>
<div class="company_num">
<p class="c_name">Insured By</p>
<p class="num">Alliance</p>
</div>
<div class="company_name">
<p class="c_name">Insured Amount</p>
<p class="name">$2,000,000</p>
</div>
<button class="btn4"><a href="pdf/certificate.pdf" download>Download certificate</a></button>
</div></div></div>

    </div>


		<div class="swiper-container container"  id="swiper1">
			<!-- Additional required wrapper -->
			<div class="swiper-wrapper">
			  
				<div class="swiper-slide circle">
							<img border=0  alt="frge"  style=" width:1200px; height:901px" src="tmplimg/1.jpg">
						</div>
						<div class="swiper-slide circle">
							<img border=0  alt=""    style=" width:1200px; height:901px" src="tmplimg/2.jpg">
						</div>
						<div class="swiper-slide circle">
							<img border=0 alt=""   style=" width:1200px; height:901px" src="tmplimg/3.jpg">
						</div>
						
			</div>
			 <!-- Add Pagination -->
			<div class="swiper-pagination"></div>
			<!-- Add Arrows -->
			
		</div>
		
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/css/swiper.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/css/swiper.min.css">


	<?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.2/jquery.min.js"><?php echo '</script'; ?>
>

	<?php echo '<script'; ?>
 src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/js/swiper.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/js/swiper.min.js"><?php echo '</script'; ?>
>


	
	
	
		<?php echo '<script'; ?>
>
		
				var mySwiper = new Swiper ('#swiper1', {
					slidesPerView: 1,
					autoplay:true,
					pagination: {
						el: '.swiper-pagination',
						type: 'progressbar',
					  },
					  navigation: {
						nextEl: '.swiper-button-next',
						prevEl: '.swiper-button-prev',
					  },
				});
				
				
		<?php echo '</script'; ?>
>
		
		



</div>
</body>

<?php echo $_smarty_tpl->getSubTemplate ("hustydesigns_framework/footer_home.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>