<?php /* Smarty version 3.1.27, created on 2019-11-27 20:46:38
         compiled from "/home/h27610/public_html/tmpl/info_box.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:8703357845ddee0ae56b176_93268190%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '38c265153c32b72bb97560196747852b287ba3f8' => 
    array (
      0 => '/home/h27610/public_html/tmpl/info_box.tpl',
      1 => 1574849728,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8703357845ddee0ae56b176_93268190',
  'variables' => 
  array (
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5ddee0ae5818c7_49306311',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5ddee0ae5818c7_49306311')) {
function content_5ddee0ae5818c7_49306311 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/h27610/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '8703357845ddee0ae56b176_93268190';
?>
<!--	<div class="col-lg-3 text-center">
				<img src="images/line1.png">
				<p class="ln1"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_days_online_generated']);?>
</p>
				<p class="ln2">Days online</p>
				</div>
              <div class="col-lg-3  text-center">
				<img src="images/line2.png">
				<p class="ln1"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_visitor_online_generated']);?>
</p>
				<p class="ln2">Total users</p>
				</div>
				<div class="col-lg-3  text-center">
				<img src="images/line3.png">
				<p class="ln1"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_deposit_funds_generated']);?>
</p>
				<p class="ln2">Total deposit</p>
				</div>
				<div class="col-lg-3  text-center">
				<img src="images/line4.png">
				<p class="ln1"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_withdraw_funds_generated']);?>
</p>
				<p class="ln2">Total withdraw</p>
				</div> --->
				       
           
            <div class="st1 text-left">
            <div class="sc1 text-left">
            <p class="sa1 text-right"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_days_online_generated']);?>
</p>
            <p class="sa2">Running days</p>
          </div>
          <img class="s1" src="images/s1.png">
        </div>
        <!---second row -->
          <div class="st2 text-center">
             <img class="s1" src="images/s2.png">
            <div class="sc1 text-left">
            <p class="sa11 text-left"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_visitor_online_generated']);?>
</p>
            <p class="sa2">Total users</p>
          </div>
         
        </div>
        <!-- third row -->
         <div class="st1 text-left">
            <div class="sc1 text-left">
            <p class="sa1 text-right">6551</p>
            <p class="sa2">Users online</p>
          </div>
          <img class="s1" src="images/s3.png">
        </div>

        <!-- fourth row --->
         <div class="st3 text-center">
             <img class="s1" src="images/s4.png">
            <div class="sc1 text-left">
            <p class="sa11 text-left"> $<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_deposit_funds_generated']);?>
</p>
            <p class="sa2">Total deposited</p>
          </div>
         
        </div>
        <!-- fifth row --->
         
            <div class="st4 text-left">
            <div class="sc1 text-left">
            <p class="sa1 text-right"> $<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_withdraw_funds_generated']);?>
</p>
            <p class="sa2">Total withdrawan</p>
          </div>
          <img class="s1" src="images/s5.png">
        </div>





<?php }
}
?>