<?php /* Smarty version 3.1.27, created on 2019-11-27 20:26:24
         compiled from "/home/h27610/public_html/tmpl/login.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:12909990305ddedbf0a90691_91156675%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd83d5d98e3eac28a99de4bef9bb60f244fa7b3d0' => 
    array (
      0 => '/home/h27610/public_html/tmpl/login.tpl',
      1 => 1574880958,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12909990305ddedbf0a90691_91156675',
  'variables' => 
  array (
    'frm' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5ddedbf0af2ae7_86287531',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5ddedbf0af2ae7_86287531')) {
function content_5ddedbf0af2ae7_86287531 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/h27610/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '12909990305ddedbf0a90691_91156675';
?>

<?php echo $_smarty_tpl->getSubTemplate ("hustydesigns_framework/header_inners.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>



<style>
	.hdcont {
display:none;
}
.scrollbar{
background:#17B897 !important;
}
header {
margin-bottom:70px !Important;
}


.new_log{


	background:url(images/login.jpg);
	background-size:cover;
	background-repeat: no-repeat;border-radius:3px;
}
.hdcont1{
 	background-color:#19BA99;
 }
.new_log{
margin-top:30px;
box-shadow: -1px 1px 10px -3px rgba(0,0,0,0.75);
-webkit-box-shadow: -1px 1px 10px -3px rgba(0,0,0,0.75);
-moz-box-shadow: -1px 1px 10px -3px rgba(0,0,0,0.75);
border-radius:3px;


}
.left_side{
padding-left:20px;
margin-left:0px;
background-color:white;
padding-top:50px;
padding-bottom:50px;}



.heading{
font-family:poppins,sans-serif;
font-size:34px;
color:gray;
font-weight:600;

}
.headingp{
 
font-size:18px;
color:gray;
margin-top:-20px ;
margin-bottom:40px;


}
.input_email{
margin-top:30px;


}
.input_email .lable  
 {
font-size:18px;
color:#19BA99;

width:320px;
}

 .input_password .lable
{
font-size:18px;
color:#19BA99;

width:300px;
padding-left:58px;
}

 input{
border:none;
line-height: 50px;
padding-left:10px;
background:none !important;

outline:none;}

.bg{
font-size:16px;
border:1px solid;
border-color:#17B897;
border-radius:3px;
width:340px;
display:block;
padding-left:10px;
margin:auto;}
.email .bg{
    width:340px;
}

.input_password{
margin-top:30px;
margin-bottom:20px;}


		
i{
color:#17B897;}

 .login-button{
border:none;
outline:none;
padding:10px 133px;
display:block;
margin: 30px auto 30px auto;
font-size:16px;
border-radius:3px;
color:white;
font-weight:600;
background-color:#17B897;
}
.left_side .for_pass{
margin-top:30px;
font-size:16px;
color:#17B897;
border-bottom:2px solid;


}


.link2:hover{
color:17b897;
background-color:white;
border:transparent;
text-decoration:none;
border-radius:3px;}
.group1{
margin-left:180px !important;
margin-top:250px !important;
width:320px;
}
.text2{
color:white;
font-size:18px;
margin-bottom:40px;}
.link2{
margin:20px 40px;
margin-top:40px !important;
color:white;
font-size:18px;
border:2px solid;
border-color:#17B897;
padding: 10px 20px;}
.hdcont{
margin-top:25px;
margin-bottom:-60px;
padding-top:30px;
padding-bottom:80px;
background: #149b80; /* Old browsers */
background: -moz-linear-gradient(-45deg, #149b80 0%, #44bf92 100%); /* FF3.6-15 */
background: -webkit-linear-gradient(-45deg, #149b80 0%,#44bf92 100%); /* Chrome10-25,Safari5.1-6 */
background: linear-gradient(135deg, #149b80 0%,#44bf92 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */}


.hdcont1{
margin-top:-70px;
padding:50px 0px 70px;}

.foot{
    margin-top:0px;
    
}





.hderrorbox  {list-style:none;background:#4677f7;margin:0;color:#fff;font-size:12px;padding:10px 20px;border-radius:3px;font-family: 'Roboto', sans-serif;}
.hderrorbox li {list-style:none;background:#fff;margin:0;color:#fff;font-size:12px;padding:10px 20px;border-radius:3px;}

</style>





<?php echo '<script'; ?>
 language=javascript>
	function checkform() {
	  if (document.mainform.username.value=='') {
		alert("Please type your username!");
		document.mainform.username.focus();
		return false;
	  }
	  if (document.mainform.password.value=='') {
		alert("Please type your password!");
		document.mainform.password.focus();
		return false;
	  }
	  return true;
	}
<?php echo '</script'; ?>
>


<?php if ($_smarty_tpl->tpl_vars['frm']->value['say'] == 'invalid_login') {?>
		<div class="hderrorbox">
		Your login or password or turing image code is wrong. Please check this information.
		</div>
		<?php }?></div></div>
	<div class="hdcont1">	
<div class="container new_log">
	<div class="row">
		<div class="col-lg-6  text-center left_side">

		
	<form method=post name=mainform onsubmit="return checkform()">
	
		<input type=hidden name=a value='do_login'>
		<input type=hidden name=follow value='<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['frm']->value['follow']);?>
'>
		<input type=hidden name=follow_id value='<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['frm']->value['follow_id']);?>
'>
		
		
		
		<p class="heading text-center">LOG IN</p>
<p class="headingp "> Enter your email and password </p>		<!--<p class="text1">Please check address</p><a href="">https://www.bitgoldtrade.com</a>--->
		
		
		
			
			<div class="input_email">
					<div class="email">
					<p class="lable  ">Email</p>
					<div class="bg text-center"> <i class="fa fa-user" aria-hidden="true"></i><input type=text name=username placeholder=" Username " value='<?php echo smarty_modifier_myescape(htmlspecialchars($_smarty_tpl->tpl_vars['frm']->value['username'], ENT_QUOTES, 'UTF-8', true));?>
'size=30 autofocus="autofocus"></div>
					
					</div>
			</div>
				
			
			<div class="input_password">
				<div class="password">
				<p class="lable  ">Password</p>
				
					<div class="bg text-center"><i class="fa fa-lock" aria-hidden="true"></i><input type=password placeholder="Password" name=password value='' size=30></div>
				</div>
			</div>
			
		
			<button type="submit" class="login-button " >LOG IN</button>
			
			<a href="<?php echo smarty_modifier_myescape(encurl("?a=forgot_password"));?>
" class="for_pass"><P>Forgot password?</P></a>
	</form>		
</div>



<!-- image --->

<div class=" col-lg-6  right">
		<div class="group1">
			<p class="text2">Not on bitexbroker Group yet?</p><a href="?a=signup" class="link2 text-center" >REGISTER</a> 
			</div>
</div></div>



</div>
</body>	</html>
</div>
<?php echo $_smarty_tpl->getSubTemplate ("hustydesigns_framework/footer_home.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>