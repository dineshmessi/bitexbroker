

 <!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  
 
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="viewport" content="width=1400; user-scalable=1;" />


  <link href="images/favicon.png" rel="icon" />
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css" />
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<!-- fonts link in the tab--->
<link href="https://fonts.googleapis.com/css?family=Bai+Jamjuree&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Bai+Jamjuree&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet"><link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet">

<style type="text/css">
  .rppp{
margin-top:50px;
font-family:poppins,sans-serif;
font-size:24px;
color:white;
}
.i1{
font-family:poppins,sans-serif;
color:#3fb090;
margin:10px 0px;
}label{
font-size:14px!important;
color:green;}

.i1 input{
border:none;
font-size:14px!important;
width:300px;
outline:none;
color:black;
background-color:rgba( 245, 245, 245 ,0.7);
padding:15px 0px 15px 10px;
height:50px;}
::placeholder{
color:#3fb090;;
font-size:14px;}
.ib button{
margin-top:20px;
outline:none;
border:none;
padding:8px 30px;
font-size:15px;
font-family:poppins,sans-serif;
border-bottom:2px solid lightgray;
}
.ib button:hover{
margin-top:20px;
outline:none;
border:none;
padding:8px 30px;
border-bottom:2px solid #3fb090;}
table {
margin-top:50px;}
table thead{
color: white;
font-size:14px!important;}
td{
padding:10px 30px !important;
font-size:16px;
color:gray;
font-weight:500;
}
.ptet1{
font-family:poppins,sans-serif;
font-size:38px;
font-weight:700;
color:white}
.ptet2{
font-family:poppins,sans-serif;
font-size:16px;
width:800px;
color:white;
margin:auto;}

.logo{
  margin:20px  0px 30px 0px;
}
.repbg{
  padding:20px 0px 60px 0px;

}
/*
.repbg{
background-image:url("images/office9.png");
background-size:cover;
padding:60px 0px;}*/
table td{
border:none !important;}
.logo a{
text-decoration:none;}

.bthm{
color:white;
border-bottom:2px solid white;
width:100px;
padding-bottom: 10px;
margin:auto;
margin:30px auto 20px auto;}

.bthm:hover{
color:gray;
border-bottom:2px solid gray;
width:100px;
margin:30px auto 20px auto;;}

.cop{
font-family:poppins,sans-serif;
font-size:13px;
color:gray;
margin:70px auto 0px auto;}
.cop1{
margin-top:0px;
color:lightgray;}
 .one_h{
display:inline-flex;


margin-top:50px;
}
      .invest{
margin-top:-60px;}
.navbar-toggler{

 margin-top:40px;
  margin-left:-200px;
}
.hd{
  margin-bottom: -10px;
}


.one_h li {
list-style-type:none;
padding:0px;
font-size:16px;
font-weight:400;
line-height:10px;
margin:0px;}
.o1l{
margin-top:-5px;
margin-left:20px;
margin-right:10px;}
.o2l{
margin-top:-10px;
margin-left:-5px;
margin-right:10px;
}
.o3l{
margin-top:-10px;
margin-right:10px;}

.dropdown1{
font-family:poppins,sans-serif;
font-size:18px ;
margin-top:44px;
margin-bottom:50px;}
.dropdown1 a{
font-size:12px;}
.pro{
margin-bottom:-120px;}
#navbarCollapse{
margin-top:-30px;
margin-left:170px;}
.container .pro_hr{
margin-top:-150px;
margin-bottom:60px;}
.navbar-toggler{
  margin-top:150px;
  margin-bottom:0px;
}
.nl1{
display:flex;
margin-top:-10px;
margin-left:-150px;}
.pro{
  margin-bottom: -20px;
}

@media only screen and (min-width: 320px) and (max-width: 1060px){
  .dropdown1{
    margin-top:60px;margin-left:250px;    
    position: relative  ;
    z-index: 99;
  }
.container hr{
display:none !important;}
.nl1{
display:block;
margin-top:-10px;
margin-left:20px;}

}
.adjust2{margin-top:-32px;

width:1000px;}
.adjust{

width:1200px;}
.pro{
margin-top:40px;
display:flex;
}
.dropdown1{
margin-top:-70px;
width:100px;
margin-left:800px;}
.bthm i{
vertical-align:middle;}
.bthm{
width:150px;
margin-bottom:20px;
color:#1ABA9C;
font-size:12px;
font-family:poppins,sans-serif;}
.bthm:hover{
width:150px;}
.ptet1 {
color:#1ABA9C;}
.ptet2{
color:gray;}
thead th{
color:white;
padding:10px 10px !important;
 font-family:poppins,sans-serif;
    border:4px solid lightgray !important;
}  
.n1h{
font-family:poppins,sans-serif;
width:250px !important;}
.one_h{
margin-right:40px;}
.dropdown1{
margin-left:880px !important;}

tr , td{
    color:white;
    
}
tr td{
    border-left:1px solid white;
    font-family:poppins,sans-serif;padding:10px 10px !important;
}








</style>
<body>
  <div class="pro container static-top">
  
        <!-- logo content--->
          <a href="./" class="navbar-brand ">
          <img src="images/logo.jpg" class="  dglogo text-center  float-center ">
          </a> <div class="top">
            <div class="container adjust"> 
            <div class="row adjust2">
              <div class="col-lg-3 one_h leo">
            
                      <li><img  class ="o1l"src="images/t1.png"></li>
                      <li class=""><p class="n1h">47 Old Gloucester Street</p>
                        <p class="n1h">London, England, </p>
                          <p class="n1h">WC1N 3AD.   </p></li>
                      </div>

                      <div class="col-lg-3 one_h">
                      <li><img class ="o2l" class ="o1l"src="images/t2.png"></li>
                      <li><p class="n1h">contact@bitexbroker.com</p>
                        <p class="n1h">  Phone Available For Vip</p></li>
                    </div>

                      <div class="col-lg-3  one_h">
                      <li><img  class="o3l"  src="images/t3.png"></li>
                      <li class=""><p class="n1h">Number : 123456789</p>
                        <p class="n1h"><a style="color:#139780" href="pdf/certificate.pdf" download>Download certificate</a></p></li>
               
                       </div>
                     </div>
                   </div>


                   <!--    <div class="dropdown1    ">


    <button class="btn  dropdown-toggle" type="button" data-toggle="dropdown"><span>English</span>
   </button><hr >
    <ul class="dropdown-menu">
      <li><a href="#">Tamil</a></li>
      <li><a href="#">German</a></li>
      <li><a href="#">French</a></li>
    </ul>
  </div>--->
</div></div>


  <div class="repbg"><div class="logo text-center">
    <a href="./">
 

<p class="bthm"> <i class="material-icons">
home_work
</i> Back to home </p></a>

  </div>
<div class=" text-center">

  <div class="ptet">
    <p class=" ptet1"> Representative</p><hr style="border-top:2px solid gray;
    width:120px;">
    <p class="ptet2"> I am grateful for the opportunities I have been given to participate in that work as a representative of my country, Canada, whose people have, I think, shown their devotion to peace.
</p>
</div></div>

  
 <table class="table-bordered container table ">
    <thead>
      <tr class="">
        
        <th style="background-color:#32776b">Name</th>
        <th style="background-color:#139780">E-mail</th>
        <th  style="background-color:#32776b">Country </th>
         <th style="background-color:#139780">Mobile number</th>
        <th style="background-color:#32776b">Skype</th>
       
      </tr>
    </thead>
    <tbody>
      

<?php 

$fileData = file_get_contents("repdb.txt");
$allUsers = explode('*end*', $fileData);

foreach($allUsers as $user) {
  $userArray = explode('*USep*',$user);
?>
<tr class="">
    
    <td style="background-color:#32776b"><?php echo $userArray[1]; ?></td>
    <td style="background-color:#139780"><?php echo $userArray[2]; ?></td>
    <td style="background-color:#32776b"><?php echo $userArray[3]; ?></td>
    <td style="background-color:#139780"><?php echo $userArray[4]; ?></td>
    <td style="background-color:#32776b"><?php echo $userArray[5]; ?></td>
</tr>


<?php } ?>

    </tbody>
  </table>

<div class="idname text-center ">




</div>


  <div class="input container">
    <p class="rppp text-center"> Are you willing to Join as <b>OUR REPRESENTATIVE </b></p>
    <form action="rep.php"   method="POST">
    <div class="i1 text-center">
      <label>Name</label>
      <br>
    <input type="text" name="name"  placeholder="Enter your name"required >
  </div>
      <div class="i1 text-center">
      <label>E-mail</label> <br>
    <input type="text" name="email" placeholder="E-mail" required >
  </div>
 
    <div class="i1 text-center">
      <label>Country</label>  <br>
    <input type="text" name="country" placeholder="Country" required >
  </div>
 
    <div class="i1 text-center">
      <label>Mobile number</label>   <br>
    <input type="text" name="number" placeholder="Mobile number"required>
  </div>
 
    <div class="i1 text-center">
      <label>Skype</label>  <br>
    <input type="text" name="skype"  placeholder="Enter your skype" required >
  </div>
 
  <div class=" ib text-center">
  <button type="submit"> Submit</button>
 </div>
 </form>

</div>



<footer>
  
 <p class="cop text-center"> Copyright ©2019 Bitex Broker Limited. All Rights Reserved.</p>
 <p class="cop cop1 text-center"> Designed by Hustydesigns</p>

</footer>
</div>
</body>
